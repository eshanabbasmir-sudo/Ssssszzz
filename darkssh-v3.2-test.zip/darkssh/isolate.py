"""
Per-user privacy boundary for DARKSSH.

Each session gets:
  - its own rootfs (other users' files are not mounted)
  - its own PID namespace (kill/ps only see processes it started)
  - its own network namespace
  - exactly 12 published ports; bind() to any other TCP/UDP port is denied
  - passwordless sudo inside that boundary (cannot escape it)

The rest of DARKSSH (API, sshx launch, UI) is unchanged.
"""

import os
import shutil
import socket
import struct
import subprocess
import threading
import time
from pathlib import Path

NETS = {}
NET_LOCK = threading.Lock()
SUBNETS = set()


def _which(name):
    return shutil.which(name) is not None


def available():
    """True when the kernel boundary can actually be enforced."""
    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        return False
    return all(_which(c) for c in ("ip", "iptables", "unshare", "mount"))


def ensure_binary(app: Path) -> Path:
    """Use the shipped helper, rebuild from source when a compiler is present."""
    src = app / "darkssh_enter.c"
    dst = app / "darkssh-enter"
    if src.exists() and _which("gcc"):
        try:
            src_m = src.stat().st_mtime
            dst_m = dst.stat().st_mtime if dst.exists() else 0
            if src_m > dst_m:
                subprocess.run(
                    ["gcc", "-O2", "-o", str(dst), str(src)],
                    check=True, timeout=60,
                )
                dst.chmod(0o755)
        except Exception:
            pass
    if not dst.exists() or not os.access(dst, os.X_OK):
        raise RuntimeError("darkssh-enter helper is missing and could not be built")
    return dst


def enable_forwarding():
    try:
        Path("/proc/sys/net/ipv4/ip_forward").write_text("1\n")
    except Exception:
        subprocess.run(
            ["sysctl", "-w", "net.ipv4.ip_forward=1"],
            check=False, capture_output=True,
        )


def egress_iface():
    try:
        out = subprocess.check_output(["ip", "route", "show", "default"], text=True, timeout=5)
        parts = out.split()
        if "dev" in parts:
            return parts[parts.index("dev") + 1]
    except Exception:
        pass
    return "eth0"


def _run(args, timeout=30, check=False):
    return subprocess.run(
        args, check=check, capture_output=True, text=True, timeout=timeout,
    )


def _alloc_subnet():
    with NET_LOCK:
        idx = 0
        while idx in SUBNETS:
            idx += 1
            if idx > 4000:
                raise RuntimeError("No free session subnets")
        SUBNETS.add(idx)
    base = idx * 4
    third = (base // 256) % 256
    fourth = base % 256
    host_ip = f"10.88.{third}.{fourth + 1}"
    guest_ip = f"10.88.{third}.{fourth + 2}"
    return idx, host_ip, guest_ip


def _release_subnet(idx):
    with NET_LOCK:
        SUBNETS.discard(idx)


def _add_rule(store, table, *args):
    cmd = ["iptables"]
    if table:
        cmd += ["-t", table]
    cmd += list(args)
    _run(cmd, timeout=15)
    store.append((table, list(args)))


def _del_rules(store):
    for table, args in reversed(store):
        args = list(args)
        if args and args[0] in ("-A", "-I"):
            args[0] = "-D"
        cmd = ["iptables"]
        if table:
            cmd += ["-t", table]
        cmd += args
        _run(cmd, timeout=15)


def setup_net(sid, ports):
    """Private netns + NAT. Only `ports` (12) are reachable from outside."""
    enable_forwarding()
    idx, host_ip, guest_ip = _alloc_subnet()
    ns = "ds" + sid[:13]
    vh = "vh" + sid[:10]
    vc = "vc" + sid[:10]
    tag = "ds" + sid[:12]
    rules = []
    try:
        _run(["ip", "netns", "del", ns], timeout=10)
    except Exception:
        pass
    try:
        _run(["ip", "link", "del", vh], timeout=10)
    except Exception:
        pass
    _run(["ip", "netns", "add", ns], timeout=10, check=True)
    _run(["ip", "link", "add", vh, "type", "veth", "peer", "name", vc], timeout=10, check=True)
    _run(["ip", "link", "set", vc, "netns", ns], timeout=10, check=True)
    _run(["ip", "addr", "add", f"{host_ip}/30", "dev", vh], timeout=10, check=True)
    _run(["ip", "link", "set", vh, "up"], timeout=10, check=True)
    _run(["ip", "netns", "exec", ns, "ip", "link", "set", "lo", "up"], timeout=10, check=True)
    _run(["ip", "netns", "exec", ns, "ip", "addr", "add", f"{guest_ip}/30", "dev", vc], timeout=10, check=True)
    _run(["ip", "netns", "exec", ns, "ip", "link", "set", vc, "up"], timeout=10, check=True)
    _run(["ip", "netns", "exec", ns, "ip", "route", "add", "default", "via", host_ip], timeout=10, check=True)

    egress = egress_iface()
    _add_rule(rules, "nat", "-A", "POSTROUTING", "-s", f"{guest_ip}/32", "-o", egress,
              "-m", "comment", "--comment", tag, "-j", "MASQUERADE")
    # Other sessions live in 10.88.0.0/16. Drop anything aimed at them.
    _add_rule(rules, None, "-I", "FORWARD", "-s", f"{guest_ip}/32", "-d", "10.88.0.0/16",
              "-m", "comment", "--comment", tag, "-j", "DROP")
    _add_rule(rules, None, "-I", "FORWARD", "-s", f"{guest_ip}/32", "-d", "192.168.0.0/16",
              "-m", "comment", "--comment", tag, "-j", "DROP")
    _add_rule(rules, None, "-I", "FORWARD", "-s", f"{guest_ip}/32", "-d", "172.16.0.0/12",
              "-m", "comment", "--comment", tag, "-j", "DROP")
    # Session must not open connections to the host itself (server, ssh, ...).
    _add_rule(rules, None, "-I", "INPUT", "-i", vh,
              "-m", "comment", "--comment", tag, "-j", "DROP")
    _add_rule(rules, None, "-A", "FORWARD", "-s", f"{guest_ip}/32",
              "-m", "comment", "--comment", tag, "-j", "ACCEPT")
    _add_rule(rules, None, "-A", "FORWARD", "-d", f"{guest_ip}/32",
              "-m", "conntrack", "--ctstate", "RELATED,ESTABLISHED",
              "-m", "comment", "--comment", tag, "-j", "ACCEPT")

    if ports:
        dports = ",".join(str(p) for p in ports)
        for proto in ("tcp", "udp"):
            _add_rule(
                rules, "nat", "-A", "PREROUTING", "-p", proto,
                "-m", "multiport", "--dports", dports,
                "-m", "comment", "--comment", tag,
                "-j", "DNAT", "--to-destination", guest_ip,
            )
            _add_rule(
                rules, None, "-A", "FORWARD", "-d", f"{guest_ip}/32", "-p", proto,
                "-m", "multiport", "--dports", dports,
                "-m", "comment", "--comment", tag, "-j", "ACCEPT",
            )

    # Inside the namespace: drop every listen that is not one of the 12 ports.
    # The user has no CAP_NET_ADMIN, so they cannot flush this.
    ns_ipt = ["ip", "netns", "exec", ns, "iptables"]
    _run(ns_ipt + ["-P", "INPUT", "DROP"], timeout=10)
    _run(ns_ipt + ["-F", "INPUT"], timeout=10)
    _run(ns_ipt + ["-A", "INPUT", "-m", "conntrack", "--ctstate", "ESTABLISHED,RELATED", "-j", "ACCEPT"], timeout=10)
    _run(ns_ipt + ["-A", "INPUT", "-p", "icmp", "-j", "ACCEPT"], timeout=10)
    if ports:
        dports = ",".join(str(p) for p in ports)
        _run(ns_ipt + ["-A", "INPUT", "-p", "tcp", "-m", "multiport", "--dports", dports, "-j", "ACCEPT"], timeout=10)
        _run(ns_ipt + ["-A", "INPUT", "-p", "udp", "-m", "multiport", "--dports", dports, "-j", "ACCEPT"], timeout=10)
    _run(ns_ipt + ["-P", "OUTPUT", "ACCEPT"], timeout=10)
    _run(ns_ipt + ["-P", "FORWARD", "DROP"], timeout=10)

    rec = {
        "sid": sid,
        "idx": idx,
        "ns": ns,
        "vh": vh,
        "vc": vc,
        "host_ip": host_ip,
        "guest_ip": guest_ip,
        "rules": rules,
        "mounts": [],
    }
    with NET_LOCK:
        NETS[sid] = rec
    return rec


def _write(path: Path, text, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    os.chmod(path, mode)
    try:
        os.chown(path, 0, 0)
    except Exception:
        pass


def _copy_tree(src, dst):
    if not os.path.exists(src):
        return
    dst = Path(dst)
    if dst.exists():
        return
    shutil.copytree(src, dst, symlinks=True, ignore_dangling_symlinks=True)


def mount_fallback_usr(root: Path, rec):
    """Private writable /usr over the host userspace. Host files are not modified."""
    upper = root.parent / "usr-upper"
    work = root.parent / "usr-work"
    if upper.exists():
        shutil.rmtree(upper, ignore_errors=True)
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    upper.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    (root / "usr").mkdir(parents=True, exist_ok=True)
    _run([
        "mount", "-t", "overlay", "overlay",
        "-o", f"lowerdir=/usr,upperdir={upper},workdir={work}",
        str(root / "usr"),
    ], timeout=20, check=True)
    rec["mounts"].append(str(root / "usr"))
    for name, target in (("bin", "usr/bin"), ("lib", "usr/lib"),
                         ("sbin", "usr/sbin"), ("lib64", "usr/lib64")):
        link = root / name
        if link.is_symlink() or link.exists():
            continue
        try:
            link.symlink_to(target)
        except Exception:
            pass
    for src, dst in (
        ("/etc/ssl", root / "etc/ssl"),
        ("/etc/apt", root / "etc/apt"),
        ("/var/lib/dpkg", root / "var/lib/dpkg"),
        ("/var/lib/apt", root / "var/lib/apt"),
        ("/etc/pam.d", root / "etc/pam.d"),
    ):
        try:
            _copy_tree(src, dst)
        except Exception:
            pass


def write_privacy_files(root: Path, sid, ports, fallback=False):
    """Sudo on, private identity, no view of other users. Does not stub tools."""
    (root / "root").mkdir(parents=True, exist_ok=True)
    (root / "workspace").mkdir(parents=True, exist_ok=True)
    (root / "tmp").mkdir(parents=True, exist_ok=True)
    (root / "home").mkdir(parents=True, exist_ok=True)
    (root / "etc").mkdir(parents=True, exist_ok=True)
    (root / "var/tmp").mkdir(parents=True, exist_ok=True)
    (root / "var/cache/apt/archives/partial").mkdir(parents=True, exist_ok=True)
    (root / "var/lib/apt/lists/partial").mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(root / "tmp", 0o1777)
        os.chmod(root / "var/tmp", 0o1777)
    except Exception:
        pass

    passwd = root / "etc/passwd"
    if fallback or not passwd.exists():
        _write(passwd,
               "root:x:0:0:root:/root:/bin/bash\n"
               "dark:x:1000:1000:dark:/root:/bin/bash\n"
               "_apt:x:100:65534::/nonexistent:/usr/sbin/nologin\n")
        _write(root / "etc/group",
               "root:x:0:\n"
               "dark:x:1000:\n"
               "nogroup:x:65534:\n")
    else:
        text = passwd.read_text(errors="replace")
        extra = ""
        if "\ndark:" not in "\n" + text and not text.startswith("dark:"):
            extra += "dark:x:1000:1000:dark:/root:/bin/bash\n"
        if "_apt:" not in text:
            extra += "_apt:x:100:65534::/nonexistent:/usr/sbin/nologin\n"
        if extra:
            passwd.write_text(text.rstrip() + "\n" + extra)
    shadow = root / "etc/shadow"
    if fallback or not shadow.exists():
        _write(shadow,
               "root:*:19000:0:99999:7:::\n"
               "dark:*:19000:0:99999:7:::\n"
               "_apt:!:19000:0:99999:7:::\n",
               mode=0o640)

    _write(root / "etc/sudoers",
           "Defaults !requiretty\n"
           "Defaults !lecture\n"
           "Defaults secure_path=\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\"\n"
           "root ALL=(ALL:ALL) NOPASSWD: ALL\n"
           "dark ALL=(ALL:ALL) NOPASSWD: ALL\n"
           "ALL ALL=(ALL:ALL) NOPASSWD: ALL\n",
           mode=0o440)
    # Permit-only PAM so sudo works in a minimal rootfs and never asks for a password.
    _write(root / "etc/pam.d/sudo",
           "#%PAM-1.0\n"
           "auth       sufficient   pam_permit.so\n"
           "account    sufficient   pam_permit.so\n"
           "session    sufficient   pam_permit.so\n")
    _write(root / "etc/pam.d/sudo-i",
           "#%PAM-1.0\n"
           "auth       sufficient   pam_permit.so\n"
           "account    sufficient   pam_permit.so\n"
           "session    sufficient   pam_permit.so\n")
    _write(root / "etc/hosts",
           "127.0.0.1 localhost dark-workspace\n"
           "::1 localhost dark-workspace\n")
    _write(root / "etc/hostname", "dark-workspace\n")
    if fallback or not (root / "etc/nsswitch.conf").exists():
        _write(root / "etc/nsswitch.conf",
               "passwd: files\n"
               "group: files\n"
               "shadow: files\n"
               "hosts: files dns\n"
               "networks: files\n"
               "protocols: files\n"
               "services: files\n")
    resolv = root / "etc/resolv.conf"
    if not resolv.exists():
        try:
            resolv.write_text(Path("/etc/resolv.conf").read_text())
        except Exception:
            resolv.write_text("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
    apt_dir = root / "etc/apt/apt.conf.d"
    apt_dir.mkdir(parents=True, exist_ok=True)
    _write(apt_dir / "99force-ipv4", 'Acquire::ForceIPv4 "true";\n')

    port_list = ", ".join(str(p) for p in (ports or []))
    motd = (
        "=============================================\n"
        "       DARKSSH — Private Workspace\n"
        "=============================================\n"
        f"  Session:  {sid}\n"
        f"  Ports:    {port_list or 'none'}\n"
        "  Sudo:     ENABLED (passwordless, this workspace only)\n"
        "  Network:  full outbound internet\n"
        "  Privacy:  other users' files, processes and ports\n"
        "            are not visible and cannot be stopped\n"
        "  Limit:    12 ports — only ones you started\n"
        "=============================================\n"
        "\n"
    )
    _write(root / "etc/motd", motd)
    _write(root / "root/.bashrc",
           "export PS1='dark@workspace:\\w\\$ '\n"
           "export TERM=${TERM:-xterm-256color}\n"
           "[ -f /etc/motd ] && cat /etc/motd\n")
    info = {
        "session_id": sid,
        "ports": list(ports or []),
        "sudo": True,
        "private": True,
    }
    try:
        import json
        _write(root / ".darkssh_session.json", json.dumps(info, indent=2))
    except Exception:
        pass
    try:
        os.chmod(root / "root", 0o700)
    except Exception:
        pass


def write_launch_script(root: Path, sid, ports):
    port_info = ",".join(str(p) for p in (ports or []))
    script = f"""#!/bin/sh
echo DARKSSH_LOCAL_READY
export HOME=/root
export USER=root
export LOGNAME=root
export HOSTNAME=dark-workspace
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export TERM="${{TERM:-dumb}}"
export DARKSSH_SESSION="{sid}"
export DARKSSH_PORTS="{port_info}"
export NETWORK_ENABLED=1
cd /root || cd /
if [ -f /etc/motd ]; then
    cat /etc/motd
fi
echo "Your 12 ports: {port_info}"
echo "Sudo is enabled. Other users cannot see or stop your processes."
echo ""
if [ -x /tmp/sshx ]; then
    exec /tmp/sshx --quiet
elif command -v sshx >/dev/null 2>&1; then
    exec sshx --quiet
elif [ -x /usr/local/bin/sshx ]; then
    exec /usr/local/bin/sshx --quiet
elif command -v curl >/dev/null 2>&1; then
    echo "Installing SSHX via curl..."
    curl -fsSL --retry 2 --max-time 40 https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/ && chmod +x /tmp/sshx && exec /tmp/sshx --quiet
elif command -v wget >/dev/null 2>&1; then
    echo "Installing SSHX via wget..."
    wget -qO- --timeout=40 https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/ && chmod +x /tmp/sshx && exec /tmp/sshx --quiet
fi
echo "SSHX binary could not be downloaded. Local terminal is active."
exec sleep infinity
"""
    path = root / "root/launch.sh"
    _write(path, script, mode=0o755)


def launch_argv(binary: Path, ns: str, root: Path, ports):
    port_s = ",".join(str(p) for p in (ports or []))
    return [
        "ip", "netns", "exec", ns,
        str(binary),
        "--root", str(root),
        "--ports", port_s,
        "--", "/bin/sh", "/root/launch.sh",
    ]


def _children(pid):
    try:
        raw = Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
        return [int(x) for x in raw if x.isdigit()]
    except Exception:
        return []


def walk_pids(pid):
    seen = set()
    stack = [pid]
    while stack:
        cur = stack.pop()
        if cur in seen:
            continue
        seen.add(cur)
        yield cur
        stack.extend(_children(cur))


def find_broker_pid(root_pid, timeout=25):
    deadline = time.time() + timeout
    while time.time() < deadline:
        for pid in list(walk_pids(root_pid)):
            sock = f"/proc/{pid}/root/run/darkssh.sock"
            if os.path.exists(sock):
                return pid
        time.sleep(0.2)
    return None


def _recvn(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            break
        buf += chunk
    return buf


def broker_exec(pid, command, timeout=180):
    path = f"/proc/{pid}/root/run/darkssh.sock"
    if not os.path.exists(path):
        found = find_broker_pid(pid, timeout=5)
        if not found:
            raise RuntimeError("Workspace broker is not ready")
        pid = found
        path = f"/proc/{pid}/root/run/darkssh.sock"
    data = command.encode()
    if len(data) > 65536:
        raise RuntimeError("Command too long")
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect(path)
        sock.sendall(struct.pack("!I", len(data)) + data)
        code_b = _recvn(sock, 4)
        len_b = _recvn(sock, 4)
        if len(code_b) < 4 or len(len_b) < 4:
            raise RuntimeError("Workspace closed the command channel")
        code = struct.unpack("!I", code_b)[0]
        out_len = struct.unpack("!I", len_b)[0]
        if out_len > 2 * 1024 * 1024:
            out_len = 2 * 1024 * 1024
        out = _recvn(sock, out_len) if out_len else b""
        return int(code), out.decode("utf-8", "replace")
    finally:
        try:
            sock.close()
        except Exception:
            pass


def teardown(sid):
    with NET_LOCK:
        rec = NETS.pop(sid, None)
    if not rec:
        return
    for mnt in rec.get("mounts", []):
        _run(["umount", "-l", mnt], timeout=15)
    _del_rules(rec.get("rules") or [])
    _run(["ip", "netns", "del", rec["ns"]], timeout=15)
    _run(["ip", "link", "del", rec["vh"]], timeout=10)
    _release_subnet(rec["idx"])


def teardown_all():
    with NET_LOCK:
        sids = list(NETS.keys())
    for sid in sids:
        try:
            teardown(sid)
        except Exception:
            pass
