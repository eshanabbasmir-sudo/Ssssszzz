/*
 * darkssh-enter — per-workspace privacy boundary for DARKSSH.
 *
 * Runs as root on the host (already inside the session network namespace).
 * Creates a private mount + PID + UTS + IPC namespace, pivot_roots into the
 * session rootfs, drops capabilities that could escape or rewrite the
 * firewall, and rejects bind() to any TCP/UDP port other than port 0
 * (ephemeral) or the 12 ports allocated to this user.
 *
 * A small command broker listens on /run/darkssh.sock so the DARKSSH server
 * can run commands inside the same boundary (local terminal) even when the
 * foreground process is sshx.
 *
 * This is not a privilege-escalation tool. It only confines a workspace the
 * operator already chose to start.
 */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/audit.h>
#include <linux/capability.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <netinet/in.h>
#include <poll.h>
#include <sched.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/sysmacros.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef __NR_pidfd_open
#define __NR_pidfd_open 434
#endif
#ifndef __NR_pidfd_getfd
#define __NR_pidfd_getfd 438
#endif
#ifndef SECCOMP_RET_USER_NOTIF
#define SECCOMP_RET_USER_NOTIF 0x7fc00000U
#endif

#define MAX_PORTS 64
#define SOCK_PATH "/run/darkssh.sock"
#define MAX_CMD 65536
#define MAX_OUT (1024 * 1024)

static int g_ports[MAX_PORTS];
static int g_nports;
static volatile sig_atomic_t g_child_died;
static pid_t g_worker = -1;

static void die(const char *msg) {
    fprintf(stderr, "darkssh-enter: %s: %s\n", msg, strerror(errno));
    _exit(1);
}

static void mkdir_p(const char *p, mode_t mode) {
    if (mkdir(p, mode) != 0 && errno != EEXIST) {
        fprintf(stderr, "darkssh-enter: mkdir %s: %s\n", p, strerror(errno));
        _exit(1);
    }
}

static int port_allowed(int port) {
    if (port == 0)
        return 1;
    for (int i = 0; i < g_nports; i++) {
        if (g_ports[i] == port)
            return 1;
    }
    return 0;
}

static void parse_ports(const char *s) {
    g_nports = 0;
    if (!s || !*s)
        return;
    while (*s && g_nports < MAX_PORTS) {
        if (!isdigit((unsigned char)*s)) {
            s++;
            continue;
        }
        int p = 0;
        while (isdigit((unsigned char)*s)) {
            p = p * 10 + (*s - '0');
            s++;
        }
        if (p > 0 && p < 65536)
            g_ports[g_nports++] = p;
    }
}

static void xmount(const char *src, const char *tgt, const char *type,
                   unsigned long flags, const char *data) {
    if (mount(src, tgt, type, flags, data) != 0) {
        fprintf(stderr, "darkssh-enter: mount %s on %s (%s): %s\n",
                src ? src : "-", tgt, type ? type : "-", strerror(errno));
        _exit(1);
    }
}

static void drop_worker_caps(void) {
    /* Keep enough for apt, sudo, ping, and ordinary root work.
       Drop anything that can leave this namespace or rewrite the firewall. */
    static const int keep[] = {
        CAP_CHOWN, CAP_DAC_OVERRIDE, CAP_DAC_READ_SEARCH, CAP_FOWNER, CAP_FSETID,
        CAP_KILL, CAP_SETGID, CAP_SETUID, CAP_SETPCAP, CAP_NET_BIND_SERVICE,
        CAP_NET_RAW, CAP_IPC_LOCK, CAP_SYS_NICE, CAP_SYS_RESOURCE, CAP_SYS_TIME,
        CAP_LEASE, CAP_AUDIT_WRITE, CAP_SETFCAP, CAP_SYS_TTY_CONFIG
    };
    int keepmask[64] = {0};
    for (unsigned i = 0; i < sizeof(keep) / sizeof(keep[0]); i++)
        keepmask[keep[i]] = 1;

    for (int cap = 0; cap < 64; cap++) {
        if (keepmask[cap])
            continue;
        syscall(SYS_prctl, PR_CAPBSET_DROP, cap, 0, 0, 0);
    }

    struct __user_cap_header_struct hdr = {
        .version = _LINUX_CAPABILITY_VERSION_3,
        .pid = 0
    };
    struct __user_cap_data_struct data[2];
    memset(data, 0, sizeof(data));
    for (int cap = 0; cap < 64; cap++) {
        if (!keepmask[cap])
            continue;
        data[cap / 32].effective |= 1u << (cap % 32);
        data[cap / 32].permitted |= 1u << (cap % 32);
        data[cap / 32].inheritable |= 1u << (cap % 32);
    }
    if (syscall(SYS_capset, &hdr, data) != 0)
        die("capset");
}

static int install_bind_filter(void) {
    struct sock_filter filter[] = {
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, nr)),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_bind, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_USER_NOTIF),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
    };
    struct sock_fprog prog = {
        .len = sizeof(filter) / sizeof(filter[0]),
        .filter = filter
    };
    /* Root still has CAP_SYS_ADMIN here, so no_new_privs is not required.
       That keeps passwordless sudo working for a non-root user. The filter
       itself cannot be removed later, even after caps are dropped. */
    int fd = syscall(SYS_seccomp, SECCOMP_SET_MODE_FILTER,
                     SECCOMP_FILTER_FLAG_NEW_LISTENER, &prog);
    if (fd < 0)
        die("seccomp bind filter");
    return fd;
}

static int send_fd(int sock, int fd) {
    struct msghdr msg;
    struct iovec iov;
    char buf[1] = {'F'};
    char cbuf[CMSG_SPACE(sizeof(int))];
    memset(&msg, 0, sizeof(msg));
    iov.iov_base = buf;
    iov.iov_len = 1;
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    memset(cbuf, 0, sizeof(cbuf));
    msg.msg_control = cbuf;
    msg.msg_controllen = sizeof(cbuf);
    struct cmsghdr *c = CMSG_FIRSTHDR(&msg);
    c->cmsg_level = SOL_SOCKET;
    c->cmsg_type = SCM_RIGHTS;
    c->cmsg_len = CMSG_LEN(sizeof(int));
    memcpy(CMSG_DATA(c), &fd, sizeof(fd));
    return sendmsg(sock, &msg, 0) < 0 ? -1 : 0;
}

static int recv_fd(int sock) {
    struct msghdr msg;
    struct iovec iov;
    char buf[1];
    char cbuf[CMSG_SPACE(sizeof(int))];
    memset(&msg, 0, sizeof(msg));
    iov.iov_base = buf;
    iov.iov_len = 1;
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    memset(cbuf, 0, sizeof(cbuf));
    msg.msg_control = cbuf;
    msg.msg_controllen = sizeof(cbuf);
    if (recvmsg(sock, &msg, 0) < 0)
        return -1;
    struct cmsghdr *c = CMSG_FIRSTHDR(&msg);
    if (!c || c->cmsg_type != SCM_RIGHTS)
        return -1;
    int fd = -1;
    memcpy(&fd, CMSG_DATA(c), sizeof(fd));
    return fd;
}

static int read_remote(pid_t pid, unsigned long addr, void *dst, size_t len) {
    struct iovec local = {.iov_base = dst, .iov_len = len};
    struct iovec remote = {.iov_base = (void *)addr, .iov_len = len};
    ssize_t n = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    return n == (ssize_t)len ? 0 : -1;
}

static int sockaddr_ok(pid_t pid, unsigned long addr, unsigned long addrlen) {
    unsigned char buf[128];
    if (addrlen < 2 || addrlen > sizeof(buf))
        return 0;
    if (read_remote(pid, addr, buf, addrlen) != 0)
        return 0;
    sa_family_t family = 0;
    memcpy(&family, buf, sizeof(family));
    /* TCP/UDP listeners are limited to this user's 12 ports (+ ephemeral 0).
       Other families must still bind: AF_UNIX for local sockets, AF_NETLINK
       for sudo/audit/apt. Denying netlink makes sudo block forever in
       recvmsg. AF_PACKET is rejected so a raw socket cannot skip the firewall. */
    if (family == AF_PACKET)
        return 0;
    if (family == AF_INET && addrlen >= sizeof(struct sockaddr_in)) {
        struct sockaddr_in in;
        memcpy(&in, buf, sizeof(in));
        return port_allowed(ntohs(in.sin_port));
    }
    if (family == AF_INET6 && addrlen >= sizeof(struct sockaddr_in6)) {
        struct sockaddr_in6 in6;
        memcpy(&in6, buf, sizeof(in6));
        return port_allowed(ntohs(in6.sin6_port));
    }
    return 1;
}

static void notif_reply(int fd, __u64 id, int err, long val) {
    struct seccomp_notif_resp resp;
    memset(&resp, 0, sizeof(resp));
    resp.id = id;
    /* This kernel's syscall_set_return_value() uses a non-zero error as the
       raw register value and does not negate it. glibc only treats a
       negative return as failure, so a positive EACCES looked like success
       and left the socket unbound. Return -errno in val instead. */
    resp.error = 0;
    resp.val = err > 0 ? -err : val;
    resp.flags = 0; /* do not CONTINUE — that is racy. We emulate bind. */
    if (ioctl(fd, SECCOMP_IOCTL_NOTIF_SEND, &resp) != 0) {
        /* target already exited */
    }
}

static void emulate_bind(int notif, struct seccomp_notif *req) {
    int allow = 0;
    int sock = -1;
    int pidfd = -1;
    unsigned long sptr = req->data.args[1];
    unsigned long slen = req->data.args[2];
    if (slen > 128)
        slen = 128;
    allow = sockaddr_ok((pid_t)req->pid, sptr, slen);

    __u64 id = req->id;
    if (ioctl(notif, SECCOMP_IOCTL_NOTIF_ID_VALID, &id) != 0) {
        return;
    }
    if (!allow) {
        notif_reply(notif, req->id, EACCES, -1);
        return;
    }

    pidfd = syscall(SYS_pidfd_open, req->pid, 0);
    if (pidfd < 0) {
        notif_reply(notif, req->id, EPERM, -1);
        return;
    }
    sock = syscall(SYS_pidfd_getfd, pidfd, (int)req->data.args[0], 0);
    if (sock < 0) {
        close(pidfd);
        notif_reply(notif, req->id, EPERM, -1);
        return;
    }
    unsigned char abuf[128];
    memset(abuf, 0, sizeof(abuf));
    if (read_remote((pid_t)req->pid, sptr, abuf, slen) != 0) {
        close(sock);
        close(pidfd);
        notif_reply(notif, req->id, EFAULT, -1);
        return;
    }
    int rc = bind(sock, (struct sockaddr *)abuf, (socklen_t)slen);
    int saved = errno;
    close(sock);
    close(pidfd);
    if (rc == 0)
        notif_reply(notif, req->id, 0, 0);
    else
        notif_reply(notif, req->id, saved ? saved : EACCES, -1);
}

static void handle_notif(int notif) {
    struct seccomp_notif req;
    memset(&req, 0, sizeof(req));
    if (ioctl(notif, SECCOMP_IOCTL_NOTIF_RECV, &req) != 0)
        return;
    if (req.data.nr == __NR_bind)
        emulate_bind(notif, &req);
    else
        notif_reply(notif, req.id, ENOSYS, -1);
}

static int write_full(int fd, const void *buf, size_t n) {
    const char *p = buf;
    while (n) {
        ssize_t w = write(fd, p, n);
        if (w < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        p += w;
        n -= w;
    }
    return 0;
}

static int read_full(int fd, void *buf, size_t n) {
    char *p = buf;
    while (n) {
        ssize_t r = read(fd, p, n);
        if (r == 0)
            return -1;
        if (r < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        p += r;
        n -= r;
    }
    return 0;
}

static void broker_client(int cfd) {
    uint32_t len = 0;
    if (read_full(cfd, &len, 4) != 0) {
        close(cfd);
        return;
    }
    len = ntohl(len);
    if (len == 0 || len > MAX_CMD) {
        close(cfd);
        return;
    }
    char *cmd = malloc(len + 1);
    if (!cmd) {
        close(cfd);
        return;
    }
    if (read_full(cfd, cmd, len) != 0) {
        free(cmd);
        close(cfd);
        return;
    }
    cmd[len] = 0;

    int pipefd[2];
    if (pipe(pipefd) != 0) {
        free(cmd);
        close(cfd);
        return;
    }
    pid_t pid = fork();
    if (pid < 0) {
        close(pipefd[0]);
        close(pipefd[1]);
        free(cmd);
        close(cfd);
        return;
    }
    if (pid == 0) {
        close(pipefd[0]);
        dup2(pipefd[1], 1);
        dup2(pipefd[1], 2);
        if (pipefd[1] > 2)
            close(pipefd[1]);
        /* Own process group so a background job cannot hold the output pipe
           open after the shell itself has exited. */
        setpgid(0, 0);
        execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
        _exit(127);
    }
    setpgid(pid, pid);
    close(pipefd[1]);
    free(cmd);
    char *out = malloc(MAX_OUT);
    size_t used = 0;
    if (out) {
        while (used < MAX_OUT) {
            ssize_t r = read(pipefd[0], out + used, MAX_OUT - used);
            if (r < 0) {
                if (errno == EINTR)
                    continue;
                break;
            }
            if (r == 0)
                break;
            used += r;
        }
    }
    close(pipefd[0]);
    int status = 0;
    while (waitpid(pid, &status, 0) < 0 && errno == EINTR) {
    }
    /* Drop background children that inherited the pipe, then finish the read. */
    kill(-pid, SIGTERM);
    usleep(50000);
    kill(-pid, SIGKILL);
    int code = 1;
    if (WIFEXITED(status))
        code = WEXITSTATUS(status);
    else if (WIFSIGNALED(status))
        code = 128 + WTERMSIG(status);
    uint32_t be_code = htonl((uint32_t)code);
    uint32_t be_len = htonl((uint32_t)used);
    write_full(cfd, &be_code, 4);
    write_full(cfd, &be_len, 4);
    if (out && used)
        write_full(cfd, out, used);
    free(out);
    close(cfd);
}

static int broker_listen(void) {
    mkdir_p("/run", 0755);
    unlink(SOCK_PATH);
    int fd = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0)
        return -1;
    struct sockaddr_un un;
    memset(&un, 0, sizeof(un));
    un.sun_family = AF_UNIX;
    strncpy(un.sun_path, SOCK_PATH, sizeof(un.sun_path) - 1);
    if (bind(fd, (struct sockaddr *)&un, sizeof(un)) != 0) {
        close(fd);
        return -1;
    }
    chmod(SOCK_PATH, 0600);
    if (listen(fd, 16) != 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static void on_sigchld(int sig) {
    (void)sig;
    g_child_died = 1;
}

static void prepare_root(const char *root) {
    if (mount(NULL, "/", NULL, MS_REC | MS_PRIVATE, NULL) != 0)
        die("make mounts private");

    char procpath[512], devpath[512], ptspath[512], tmppath[512];
    char runpath[512], shmpath[512], oldpath[512], syspath[512];
    snprintf(procpath, sizeof(procpath), "%s/proc", root);
    snprintf(devpath, sizeof(devpath), "%s/dev", root);
    snprintf(ptspath, sizeof(ptspath), "%s/dev/pts", root);
    snprintf(tmppath, sizeof(tmppath), "%s/tmp", root);
    snprintf(runpath, sizeof(runpath), "%s/run", root);
    snprintf(shmpath, sizeof(shmpath), "%s/dev/shm", root);
    snprintf(oldpath, sizeof(oldpath), "%s/oldroot", root);
    snprintf(syspath, sizeof(syspath), "%s/sys", root);
    mkdir_p(procpath, 0755);
    mkdir_p(devpath, 0755);
    mkdir_p(tmppath, 01777);
    mkdir_p(runpath, 0755);
    mkdir_p(oldpath, 0755);
    mkdir_p(syspath, 0555);
    mkdir_p(root, 0755);

    /* MS_REC so a /usr (or overlay) bind already mounted under the rootfs
       is visible after pivot_root. A non-recursive bind would hide it. */
    if (mount(root, root, NULL, MS_BIND | MS_REC, NULL) != 0)
        die("bind root");
    xmount("proc", procpath, "proc", MS_NOSUID | MS_NODEV | MS_NOEXEC, NULL);
    xmount("tmpfs", devpath, "tmpfs", MS_NOSUID | MS_STRICTATIME, "mode=755,size=64m");
    mkdir_p(ptspath, 0755);
    mkdir_p(shmpath, 01777);
    xmount("devpts", ptspath, "devpts", MS_NOSUID | MS_NOEXEC,
           "newinstance,ptmxmode=0666,mode=0620");
    xmount("tmpfs", shmpath, "tmpfs", MS_NOSUID | MS_NODEV, "mode=1777,size=256m");
    xmount("tmpfs", tmppath, "tmpfs", MS_NOSUID | MS_NODEV, "mode=1777,size=512m");
    xmount("tmpfs", runpath, "tmpfs", MS_NOSUID | MS_NODEV, "mode=755,size=64m");

    const char *nodes[][3] = {
        {"/dev/null", "1", "3"},
        {"/dev/zero", "1", "5"},
        {"/dev/full", "1", "7"},
        {"/dev/random", "1", "8"},
        {"/dev/urandom", "1", "9"},
        {"/dev/tty", "5", "0"},
        {NULL, NULL, NULL}
    };
    for (int i = 0; nodes[i][0]; i++) {
        char p[512];
        snprintf(p, sizeof(p), "%s%s", root, nodes[i][0]);
        dev_t dev = makedev(atoi(nodes[i][1]), atoi(nodes[i][2]));
        if (mknod(p, S_IFCHR | 0666, dev) != 0 && errno != EEXIST)
            fprintf(stderr, "darkssh-enter: mknod %s: %s\n", p, strerror(errno));
    }
    char ptmx[512];
    snprintf(ptmx, sizeof(ptmx), "%s/dev/ptmx", root);
    unlink(ptmx);
    if (symlink("pts/ptmx", ptmx) != 0 && errno != EEXIST)
        fprintf(stderr, "darkssh-enter: ptmx symlink: %s\n", strerror(errno));

    if (chdir(root) != 0)
        die("chdir root");
    if (syscall(SYS_pivot_root, ".", "oldroot") != 0)
        die("pivot_root");
    if (chdir("/") != 0)
        die("chdir /");
    if (umount2("/oldroot", MNT_DETACH) != 0)
        die("umount old root");
    rmdir("/oldroot");
    sethostname("dark-workspace", 14);
}

static void broker_loop(void) {
    int broker = broker_listen();
    if (broker < 0)
        die("broker socket");
    for (;;) {
        int c = accept(broker, NULL, NULL);
        if (c < 0) {
            if (errno == EINTR)
                continue;
            _exit(1);
        }
        pid_t h = fork();
        if (h == 0) {
            close(broker);
            /* Double-fork so a slow command cannot block the next one. */
            pid_t g = fork();
            if (g == 0) {
                int devnull = open("/dev/null", O_RDONLY);
                if (devnull >= 0) {
                    dup2(devnull, 0);
                    if (devnull > 0)
                        close(devnull);
                }
                broker_client(c);
                _exit(0);
            }
            close(c);
            _exit(0);
        }
        close(c);
        if (h > 0) {
            int st;
            while (waitpid(h, &st, 0) < 0 && errno == EINTR) {
            }
        }
    }
}

static int child_worker(const char *root, int ready_fd, char **argv) {
    prepare_root(root);
    int notif = install_bind_filter();
    if (send_fd(ready_fd, notif) != 0)
        die("send seccomp fd");
    close(notif);
    close(ready_fd);
    drop_worker_caps();
    /* Broker inherits the bind filter and the dropped capability set, so a
       command issued through /run/darkssh.sock cannot escape or open extra
       ports. It is started before exec so it survives as sshx's sibling. */
    pid_t broker = fork();
    if (broker < 0)
        die("fork broker");
    if (broker == 0)
        broker_loop();
    execv(argv[0], argv);
    die("exec workspace command");
    return 1;
}

static int supervisor(int ready_fd) {
    int notif = recv_fd(ready_fd);
    close(ready_fd);
    if (notif < 0)
        die("recv seccomp fd");

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_sigchld;
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigaction(SIGCHLD, &sa, NULL);

    int worker_status = 0;
    int worker_reaped = 0;
    while (!worker_reaped) {
        struct pollfd pf;
        pf.fd = notif;
        pf.events = POLLIN;
        int pr = poll(&pf, 1, 400);
        if (pr < 0 && errno != EINTR)
            break;
        if (pr > 0 && (pf.revents & POLLIN))
            handle_notif(notif);
        if (g_child_died || g_worker > 0) {
            int status;
            pid_t w;
            while ((w = waitpid(-1, &status, WNOHANG)) > 0) {
                if (w == g_worker) {
                    worker_reaped = 1;
                    if (WIFEXITED(status))
                        worker_status = WEXITSTATUS(status);
                    else if (WIFSIGNALED(status))
                        worker_status = 128 + WTERMSIG(status);
                }
            }
            g_child_died = 0;
        }
    }
    close(notif);
    return worker_status;
}

static void usage(void) {
    fprintf(stderr,
            "usage: darkssh-enter --root ROOT --ports p1,p2,.. -- CMD [ARGS]\n");
}

int main(int argc, char **argv) {
    const char *root = NULL;
    const char *ports = "";
    int cmd_at = -1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--root") == 0 && i + 1 < argc) {
            root = argv[++i];
        } else if (strcmp(argv[i], "--ports") == 0 && i + 1 < argc) {
            ports = argv[++i];
        } else if (strcmp(argv[i], "--") == 0) {
            cmd_at = i + 1;
            break;
        } else {
            usage();
            return 2;
        }
    }
    if (!root || cmd_at < 0 || cmd_at >= argc) {
        usage();
        return 2;
    }
    parse_ports(ports);

    if (unshare(CLONE_NEWNS | CLONE_NEWPID | CLONE_NEWUTS | CLONE_NEWIPC) != 0)
        die("unshare");

    int sv[2];
    if (socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0, sv) != 0)
        die("socketpair");

    pid_t pid = fork();
    if (pid < 0)
        die("fork");
    if (pid == 0) {
        /* PID 1 of the new pid namespace. Keep sv[0]; worker gets sv[1]. */
        g_worker = fork();
        if (g_worker < 0)
            die("fork worker");
        if (g_worker == 0) {
            close(sv[0]);
            return child_worker(root, sv[1], argv + cmd_at);
        }
        close(sv[1]);
        return supervisor(sv[0]);
    }
    close(sv[0]);
    close(sv[1]);
    int status = 0;
    if (waitpid(pid, &status, 0) < 0)
        die("wait");
    if (WIFEXITED(status))
        return WEXITSTATUS(status);
    if (WIFSIGNALED(status))
        return 128 + WTERMSIG(status);
    return 1;
}
