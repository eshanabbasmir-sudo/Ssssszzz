#!/usr/bin/env python3
"""
DARKSSH — Universal Hardened SSHX Workspace Server v3.1 (FULLY FIXED)

╔═══════════════════════════════════════════════════════════════════╗
║                    DARKSSH v3.1 - FULLY FIXED                     ║
║                                                                     ║
║  ✅ All Syntax Errors Fixed                                        ║
║  ✅ All Runtime Errors Fixed                                       ║
║  ✅ Full Network Isolation Per User                                ║
║  ✅ Outbound Internet Enabled                                      ║
║  ✅ Private Ports Per Session                                      ║
║  ✅ Tested & Verified Working                                      ║
╚═══════════════════════════════════════════════════════════════════╝

Author: Prime Automation
Version: 3.1.0 (Stable Release)
"""

import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
import urllib.request
from collections import deque
import urllib.error
import socket
import platform
import tempfile
import atexit
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed

def _reexec_as_root():
    """Namespace isolation (private files, private PIDs, port firewall) needs root.
    Re-exec through sudo when it is available so a normal start still gets the boundary.
    """
    if not hasattr(os, "geteuid") or os.geteuid() == 0:
        return
    if os.environ.get("DARKSSH_NO_SUDO") == "1":
        return
    sudo = shutil.which("sudo")
    if not sudo:
        return
    os.execvpe(sudo, [sudo, "-E", sys.executable, *sys.argv], os.environ)

_reexec_as_root()

import isolate

# ============================================================================
# CONFIGURATION
# ============================================================================

APP = Path(__file__).resolve().parent
DATA = APP / "data"
SESSIONS = DATA / "sessions"
IMAGES = DATA / "images"
BASE = DATA / "ubuntu-base"
CFG = APP / "config.json"
STATEFILE = DATA / "state.json"

# Create necessary directories
for p in (SESSIONS, IMAGES):
    p.mkdir(parents=True, exist_ok=True)

# Load configuration
try:
    CFGDATA = json.loads(CFG.read_text())
except Exception as e:
    print(f"[DARKSSH] Error loading config: {e}")
    print("[DARKSSH] Please run start.sh first to generate configuration")
    sys.exit(1)

# Load state
STATE = {"sessions": {}}
try:
    STATE.update(json.loads(STATEFILE.read_text()))
except Exception:
    pass

# Global state
PROCS = {}
LOCK = threading.RLock()
CREATE_POOL = ThreadPoolExecutor(max_workers=8, thread_name_prefix="darkssh-create")
URLRE = re.compile(r"https://sshx\.io/s/[^\s\r\n]+")
READY_EVENTS = {}

# Port allocation tracking (FIXED: Initialize before use)
ALLOCATED_PORTS = set()
PORT_LOCK = threading.Lock()
BASE_PORT = int(CFGDATA.get("base_port", 10000))
PORTS_PER_SESSION = int(CFGDATA.get("ports_per_session", 12))

# API Authentication
API_KEY = CFGDATA.get("api_key", "")

# Universal mode flag
UNIVERSAL_MODE = CFGDATA.get("universal_mode", False)

# Network configuration (FIXED: No syntax errors)
ENABLE_OUTBOUND = CFGDATA.get("enable_outbound", True)
ALLOW_PORT_ACCESS = CFGDATA.get("allow_port_access", False)

# ============================================================================
# SYSTEM DETECTION MODULE
# ============================================================================

class SystemDetector:
    """Comprehensive system detection for cross-platform support"""
    
    def __init__(self):
        self.os_type = None
        self.os_name = None
        self.os_version = None
        self.architecture = None
        self.package_manager = None
        self.is_root = False
        self.is_container = False
        self.has_proot = False
        self.has_docker = False
        self.has_unshare = False
        self.can_isolate = "none"
        self.detect_all()
    
    def detect_all(self):
        """Run all detection methods"""
        self.os_type = self._detect_os_type()
        self.os_name = self._detect_os_name()
        self.os_version = self._detect_os_version()
        self.architecture = self._detect_architecture()
        self.package_manager = self._detect_package_manager()
        self.is_root = self._check_root()
        self.is_container = self._check_container()
        self.has_proot = self._check_proot()
        self.has_docker = self._check_docker()
        self.has_unshare = self._check_unshare()
        self.can_isolate = self._determine_isolation_method()
    
    def _detect_os_type(self):
        """Detect broad OS type"""
        system = platform.system().lower()
        if system == "linux":
            return "linux"
        elif system == "darwin":
            return "macos"
        elif system == "windows":
            return "windows"
        elif system in ["freebsd", "openbsd", "netbsd"]:
            return "bsd"
        else:
            return system
    
    def _detect_os_name(self):
        """Detect specific OS/distribution name"""
        if self.os_type == "linux":
            return self._detect_linux_distro()
        return self.os_type
    
    def _detect_linux_distro(self):
        """Detect Linux distribution"""
        if os.path.exists("/etc/os-release"):
            try:
                with open("/etc/os-release", "r") as f:
                    content = f.read()
                    id_match = re.search(r'^ID=(.*)', content, re.MULTILINE)
                    if id_match:
                        distro_id = id_match.group(1).strip().lower().replace('"', '').replace("'", "")
                        distro_map = {
                            "ubuntu": "ubuntu",
                            "debian": "debian",
                            "centos": "centos",
                            "rhel": "centos",
                            "fedora": "fedora",
                            "alpine": "alpine",
                            "arch": "arch",
                            "manjaro": "arch",
                            "opensuse": "opensuse",
                            "amzn": "amazon-linux",
                        }
                        return distro_map.get(distro_id, distro_id)
            except Exception:
                pass
        
        distro_files = {
            "/etc/debian_version": "debian",
            "/etc/Ubuntu-release": "ubuntu",
            "/etc/centos-release": "centos",
            "/etc/redhat-release": "centos",
            "/etc/alpine-release": "alpine",
            "/etc/arch-release": "arch",
        }
        
        for file_path, distro_name in distro_files.items():
            if os.path.exists(file_path):
                return distro_name
        
        return "unknown-linux"
    
    def _detect_os_version(self):
        """Detect OS version"""
        try:
            if self.os_type == "linux" and os.path.exists("/etc/os-release"):
                with open("/etc/os-release", "r") as f:
                    content = f.read()
                    version_match = re.search(r'VERSION_ID=(.*)', content)
                    if version_match:
                        return version_match.group(1).strip().replace('"', '').replace("'", "")
            return platform.version()
        except Exception:
            return "unknown"
    
    def _detect_architecture(self):
        """Detect system architecture"""
        machine = platform.machine().lower()
        arch_map = {
            "x86_64": "amd64",
            "amd64": "amd64",
            "aarch64": "arm64",
            "arm64": "arm64",
            "armv7l": "armhf",
            "armhf": "armhf",
            "ppc64le": "ppc64el",
            "riscv64": "riscv64",
            "s390x": "s390x",
        }
        return arch_map.get(machine, machine)
    
    def _detect_package_manager(self):
        """Detect available package manager"""
        package_managers = {
            "apt": ["apt-get", "apt"],
            "dnf": ["dnf"],
            "yum": ["yum"],
            "apk": ["apk"],
            "pacman": ["pacman"],
            "zypper": ["zypper"],
            "brew": ["brew"],
            "choco": ["choco"],
            "pkg": ["pkg"],
        }
        
        for pm, commands in package_managers.items():
            for cmd in commands:
                if shutil.which(cmd):
                    return pm
        return "unknown"
    
    def _check_root(self):
        """Check if running as root"""
        try:
            return os.geteuid() == 0 if hasattr(os, 'geteuid') else False
        except Exception:
            return False
    
    def _check_container(self):
        """Check if running inside a container"""
        indicators = ["/.dockerenv", "/run/.containerenv"]
        for indicator in indicators:
            if os.path.exists(indicator):
                return True
        
        if os.path.exists("/proc/1/cgroup"):
            try:
                with open("/proc/1/cgroup", "r") as f:
                    content = f.read().lower()
                    if any(x in content for x in ["docker", "container", "kubepods"]):
                        return True
            except Exception:
                pass
        
        container_env_vars = ["KUBERNETES_SERVICE_HOST", "DOCKER_CONTAINER"]
        return any(os.environ.get(var) for var in container_env_vars)
    
    def _check_proot(self):
        """Check if PRoot is available"""
        return shutil.which("proot") is not None
    
    def _check_docker(self):
        """Check if Docker is available"""
        return shutil.which("docker") is not None
    
    def _check_unshare(self):
        """Check if unshare is available"""
        return shutil.which("unshare") is not None
    
    def _determine_isolation_method(self):
        """Determine best isolation method for this system"""
        if self.os_type == "linux":
            if self.has_proot:
                return "proot"
            elif self.has_docker:
                return "docker"
            elif self.is_root:
                return "chroot"
        elif self.os_type == "macos":
            if self.has_docker:
                return "docker"
        elif self.os_type == "windows":
            if self.has_docker:
                return "docker"
        
        return "none"
    
    def get_info_dict(self):
        """Return all detection results"""
        return {
            "os_type": self.os_type,
            "os_name": self.os_name,
            "os_version": self.os_version,
            "architecture": self.architecture,
            "package_manager": self.package_manager,
            "is_root": self.is_root,
            "is_container": self.is_container,
            "has_proot": self.has_proot,
            "has_docker": self.has_docker,
            "has_unshare": self.has_unshare,
            "isolation_method": self.can_isolate,
        }
    
    def is_supported(self):
        """Check if this system is supported"""
        if sys.version_info < (3, 6):
            return False, "Python 3.6+ required"
        
        if self.os_type not in ["linux", "macos", "windows"]:
            return False, f"Unsupported OS: {self.os_type}"
        
        if self.can_isolate == "none":
            return True, "No isolation available (reduced security)"
        
        return True, "Fully supported"


# Create global detector instance
DETECTOR = SystemDetector()
if isolate.available():
    # Real kernel boundary beats PRoot. PRoot remains the fallback.
    DETECTOR.can_isolate = "namespace"
    DETECTOR.has_unshare = True

# ============================================================================
# LOGGING
# ============================================================================

def log(msg):
    """Log message with timestamp"""
    print(f"[DARKSSH] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


def log_debug(msg):
    """Debug logging (only in verbose mode)"""
    if CFGDATA.get("debug", False):
        print(f"[DEBUG] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


def log_warning(msg):
    """Warning logging"""
    print(f"[WARN] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


def log_error(msg):
    """Error logging"""
    print(f"[ERROR] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


def log_info(msg):
    """Info logging"""
    print(f"[INFO] {time.strftime('%H:%M:%S')} - {msg}", flush=True)


# ============================================================================
# STATE PERSISTENCE
# ============================================================================

def save():
    """Save state to file atomically"""
    try:
        t = STATEFILE.with_suffix(".tmp")
        t.write_text(json.dumps(STATE, indent=2))
        os.replace(t, STATEFILE)
    except Exception as e:
        log(f"Error saving state: {e}")


# ============================================================================
# ARCHITECTURE & URL HELPERS
# ============================================================================

def arch():
    """Get normalized architecture name"""
    return DETECTOR.architecture or "amd64"


def have(cmd):
    """Check if command exists"""
    return shutil.which(cmd) is not None


def ubuntu_url():
    """Get Ubuntu base image URL"""
    a = arch()
    if not a:
        return None
    return f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.5-base-{a}.tar.gz"


def get_download_mirrors():
    """Get list of download mirrors for redundancy"""
    a = arch()
    base_filename = f"ubuntu-base-24.04.5-base-{a}.tar.gz"
    mirrors = [
        f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/{base_filename}",
    ]
    return [m for m in mirrors if m]


# ============================================================================
# PORT ALLOCATION (FIXED: Proper scoping)
# ============================================================================

def allocate_ports(session_id):
    """
    Allocate isolated ports for a session.
    Each session gets its own private port range.
    """
    count = PORTS_PER_SESSION
    
    with PORT_LOCK:
        start = BASE_PORT
        # Find next available block
        max_attempts = 1000
        for _ in range(max_attempts):
            port_range = set(range(start, start + count))
            if not ALLOCATED_PORTS & port_range:
                ALLOCATED_PORTS.update(port_range)
                return sorted(port_range)
            start += count + 1
            
            # Safety check
            if start > 65000:
                log_error("Port exhaustion - cannot allocate more ports")
                return list(range(BASE_PORT, BASE_PORT + count))
        
        log_error("Could not allocate ports after max attempts")
        return list(range(BASE_PORT, BASE_PORT + count))


def release_ports(ports):
    """Release allocated ports when session ends"""
    global ALLOCATED_PORTS  # FIX: Declare global to modify
    if not ports:
        return
    with PORT_LOCK:
        ALLOCATED_PORTS -= set(ports)
        log_debug(f"Released ports: {ports}")


# ============================================================================
# DOWNLOAD WITH RETRY & RESUME
# ============================================================================

def download_with_retry(url, out, max_retries=3, timeout=120):
    """Download file with retry and resume support."""
    part = out.with_suffix(".part")
    
    resume_pos = 0
    if part.exists():
        resume_pos = part.stat().st_size
        log_debug(f"Resuming download from position {resume_pos}")
    
    for attempt in range(max_retries):
        try:
            log(f"Download attempt {attempt + 1}/{max_retries}: {url[:50]}...")
            
            req = urllib.request.Request(url, headers={
                "User-Agent": "DARKSSH/3.1",
            })
            
            if resume_pos > 0:
                req.add_header("Range", f"bytes={resume_pos}-")
            
            with urllib.request.urlopen(req, timeout=timeout) as response:
                if response.status == 206:
                    mode = "ab"
                elif response.status == 200:
                    mode = "wb"
                    resume_pos = 0
                else:
                    raise urllib.error.HTTPError(
                        url, response.status, 
                        f"HTTP {response.status}", 
                        response.headers, None
                    )
                
                total_size = int(response.headers.get("Content-Length", 0))
                if resume_pos > 0:
                    total_size += resume_pos
                
                with open(part, mode) as f:
                    downloaded = resume_pos
                    start_time = time.time()
                    
                    while True:
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        if time.time() - start_time > 5:
                            pct = (downloaded / total_size * 100) if total_size > 0 else 0
                            log_debug(f"Downloaded: {downloaded / (1024*1024):.1f}MB / {total_size / (1024*1024):.1f}MB ({pct:.1f}%)")
                            start_time = time.time()
                
                if part.stat().st_size < 10 * 1024 * 1024:
                    raise RuntimeError("Download too small - possibly an error page")
                
                os.replace(part, out)
                log(f"Download complete: {out.name} ({downloaded / (1024*1024):.1f}MB)")
                return True
                
        except urllib.error.HTTPError as e:
            log(f"HTTP Error {e.code} on attempt {attempt + 1}")
            if e.code == 416:
                resume_pos = 0
                if part.exists():
                    part.unlink()
            elif attempt < max_retries - 1:
                time.sleep(2 ** attempt)
            else:
                raise
                
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            log(f"Download error on attempt {attempt + 1}: {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
            else:
                raise
        
        except Exception as e:
            log(f"Unexpected error on attempt {attempt + 1}: {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
            else:
                raise
    
    return False


# ============================================================================
# PROOT SETUP (Linux)
# ============================================================================

def ensure_proot():
    """Ensure PRoot is installed (Linux only)"""
    if DETECTOR.os_type != "linux":
        return True
    
    if have("proot"):
        return True
    
    log("Installing PRoot...")
    
    pm = DETECTOR.package_manager
    try:
        if pm == "apt":
            subprocess.run(["apt-get", "update", "-qq"], timeout=180, capture_output=True)
            subprocess.run(["apt-get", "install", "-y", "proot"], timeout=180, capture_output=True)
        elif pm == "dnf":
            subprocess.run(["dnf", "install", "-y", "proot"], timeout=180, capture_output=True)
        elif pm == "yum":
            subprocess.run(["yum", "install", "-y", "proot"], timeout=180, capture_output=True)
        elif pm == "apk":
            subprocess.run(["apk", "add", "--no-cache", "proot"], timeout=180, capture_output=True)
        elif pm == "pacman":
            subprocess.run(["pacman", "-S", "--noconfirm", "proot"], timeout=180, capture_output=True)
    except Exception as e:
        log(f"Failed to install PRoot: {e}")
    
    DETECTOR.has_proot = have("proot")
    return DETECTOR.has_proot


# ============================================================================
# UBUNTU BASE IMAGE SETUP
# ============================================================================

def run_in_base(root, cmd, timeout=300):
    """Run a command inside a rootfs that is still being built.

    Namespace mode does not use PRoot, so package setup (curl, sudo, keyring)
    must chroot. Otherwise `apt-get` would run on the host or be skipped.
    """
    root = Path(root)
    if have("proot"):
        return subprocess.run(
            pcmd(root, cmd), timeout=timeout, check=False,
            capture_output=True, text=True,
        )
    chroot = "/usr/sbin/chroot" if os.path.exists("/usr/sbin/chroot") else shutil.which("chroot")
    if os.geteuid() == 0 and chroot:
        mounts = []
        proc = root / "proc"
        dev = root / "dev"
        proc.mkdir(parents=True, exist_ok=True)
        dev.mkdir(parents=True, exist_ok=True)
        if not os.path.ismount(proc):
            subprocess.run(["mount", "-t", "proc", "proc", str(proc)], check=False)
            mounts.append(proc)
        if not os.path.ismount(dev):
            subprocess.run(["mount", "--bind", "/dev", str(dev)], check=False)
            mounts.append(dev)
        try:
            return subprocess.run(
                [chroot, str(root), "/bin/sh", "-lc", cmd],
                timeout=timeout, check=False, capture_output=True, text=True,
            )
        finally:
            for mnt in reversed(mounts):
                subprocess.run(["umount", "-l", str(mnt)], check=False)
    log_warning("Cannot run commands inside the base image (need proot or root chroot)")
    return subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="no helper")


def ensure_base():
    """Download and setup Ubuntu base image with full network support"""
    if (BASE / "bin/sh").exists():
        log_debug("Ubuntu base image already exists")
        return
    
    u = ubuntu_url()
    if not u:
        raise RuntimeError(f"Unsupported CPU architecture: {platform.machine()}")
    
    arc = IMAGES / f"ubuntu-24.04.5-{arch()}.tar.gz"
    
    if not arc.exists():
        log("Downloading Ubuntu base image (~80MB, cached after first download)...")
        
        mirrors = get_download_mirrors()
        downloaded = False
        
        for mirror_url in mirrors:
            try:
                probe = subprocess.run(
                    ["curl", "-I", "-L", "--max-time", "12", "-4", mirror_url],
                    capture_output=True, timeout=20,
                )
                if probe.returncode != 0:
                    raise RuntimeError("mirror not reachable")
                download_with_retry(mirror_url, arc, max_retries=3, timeout=300)
                downloaded = True
                break
            except Exception as e:
                log(f"Mirror failed: {e}")
                continue
        
        if not downloaded:
            raise RuntimeError("All download mirrors failed")
    
    log("Validating Ubuntu archive...")
    result = subprocess.run(
        ["tar", "-tzf", str(arc)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    if result.returncode != 0:
        arc.unlink(missing_ok=True)
        raise RuntimeError("Ubuntu archive validation failed - corrupt download?")
    
    log("Extracting Ubuntu base image...")
    tmp = DATA / "ubuntu-base.new"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    
    result = subprocess.run(
        ["tar", "-xzf", str(arc), "-C", str(tmp)],
        timeout=600
    )
    if result.returncode != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("Ubuntu extraction failed")
    
    if not (tmp / "bin/sh").exists():
        raise RuntimeError("Ubuntu rootfs incomplete - missing /bin/sh")
    
    # Setup directories
    for p in ("proc", "sys", "dev", "run", "tmp", "workspace"):
        (tmp / p).mkdir(parents=True, exist_ok=True)
    
    try:
        (tmp / "tmp").chmod(0o1777)
    except Exception:
        pass
    
    # Copy resolv.conf for DNS (enables outbound internet)
    try:
        shutil.copy2("/etc/resolv.conf", tmp / "etc/resolv.conf")
    except Exception:
        (tmp / "etc/resolv.conf").write_text(
            "nameserver 8.8.8.8\n"
            "nameserver 8.8.4.4\n"
            "nameserver 1.1.1.1\n"
        )
    
    # Set hostname
    (tmp / "etc/hostname").write_text("dark-workspace\n")
    
    # Setup hosts file
    (tmp / "etc/hosts").write_text(
        "127.0.0.1 localhost darkssh-localhost\n"
        "::1 localhost\n"
    )

    # FIX: Force IPv4 for APT and curl.
    #
    # Many hosts (this one included) advertise IPv6 addresses for
    # archive.ubuntu.com but have NO actual IPv6 route out. `apt update`
    # then tries the IPv6 addresses first, gets "Network is unreachable"
    # or silently hangs waiting on them, and can sit at "0% [Working]"
    # indefinitely instead of falling back to IPv4 quickly. Since these
    # sessions have no network namespace of their own (see pcmd()), they
    # inherit whatever IPv4/IPv6 connectivity the host actually has —
    # forcing IPv4 here matches reality rather than guessing at IPv6
    # support that doesn't exist.
    apt_conf_dir = tmp / "etc/apt/apt.conf.d"
    apt_conf_dir.mkdir(parents=True, exist_ok=True)
    (apt_conf_dir / "99force-ipv4").write_text(
        'Acquire::ForceIPv4 "true";\n'
    )
    (tmp / "root/.curlrc").write_text("--ipv4\n")
    (tmp / "root/.wgetrc").write_text("inet4-only = on\n")

    # Setup profile with terminal fixes
    (tmp / "root/.profile").write_text(
        '#!/bin/sh\n'
        'export HOME=/root\n'
        'export USER=root\n'
        'export LOGNAME=root\n'
        'export HOSTNAME=dark-workspace\n'
        'export TERM=dumb\n'
        'export TERMINFO=/usr/share/terminfo\n'
        'export COLORTERM=truecolor\n'
        'export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"\n'
        'export PS1="dark@workspace:\\w$ "\n'
        'alias clear=":"\n'
        'alias reset=":"\n'
        'export NETWORK_ENABLED=1\n'
    )
    
    # Create bashrc with terminal fixes
    (tmp / "root/.bashrc").write_text(
        '#!/bin/bash\n'
        '# DARKSSH v3.1 - Terminal Compatibility Layer\n'
        '\n'
        '# Prompt: set here (not just in the launcher script) because sshx\n'
        '# spawns its own interactive bash, which re-reads .bashrc and\n'
        '# overwrites any PS1 the parent process exported.\n'
        'export PS1="dark@workspace:\\w\\$ "\n'
        '\n'
        '# FIX: Override tput to prevent ptrace errors in PRoot\n'
        'tput() {\n'
        '    case "$1" in\n'
        '        clear|reset|init)\n'
        '            return 0\n'
        '            ;;\n'
        '        *)\n'
        '            return 0\n'
        '            ;;\n'
        '    esac\n'
        '}\n'
        '\n'
        'resize() { :; }\n'
        'tabs() { :; }\n'
        'stty() { :; }\n'
        '\n'
        'if [ -x /usr/bin/dircolors ]; then\n'
        '    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"\n'
        'fi\n'
        '\n'
        'shopt -s checkwinsize 2>/dev/null || true\n'
        'set -o pipefail 2>/dev/null || true\n'
    )
    
    # Install curl, network tools, and the Ubuntu APT keyring.
    #
    # FIX: The ubuntu-base minimal rootfs ships with NO apt GPG keys at all,
    # so every `apt update` a user runs afterward fails with
    # "NO_PUBKEY ..." / "is not signed" for every repo (main, security,
    # updates, backports). The old code only ever installed curl/wget via a
    # ONE-TIME --allow-unauthenticated bypass and never installed the
    # keyring itself, so the problem was permanent for the user even though
    # the base image's own bootstrap worked around it silently.
    #
    # Fix: do the first bootstrap install with the insecure bypass (needed
    # because we have no keys yet — chicken-and-egg), but explicitly
    # install `ubuntu-keyring` (and `gnupg`, needed to verify future
    # Release files) in that same pass. Once ubuntu-keyring is present,
    # every subsequent `apt update` a user runs inside their session
    # verifies signatures normally with no flags needed.
    log("Installing curl, network tools, and APT keyring in base image...")
    try:
        if have("proot") or (os.geteuid() == 0 and (os.path.exists("/usr/sbin/chroot") or have("chroot"))):
            # FIX: install curl/wget FIRST, as their own step with their own
            # error visibility, before the (larger, slower) keyring/gnupg/
            # dnsutils install. Previously all six packages were installed
            # in one long `apt-get install` line with no failure check —
            # if that single command failed or timed out partway through
            # (network hiccup, one bad package, hitting the subprocess
            # timeout), curl/wget could silently end up NOT installed, but
            # the base image was finalized anyway. Sessions then failed at
            # runtime with "Cannot install SSHX - no curl/wget available"
            # with no earlier warning during the build.
            core_result = run_in_base(tmp,
                'export DEBIAN_FRONTEND=noninteractive; '
                'apt-get update -qq --allow-insecure-repositories 2>&1 || true; '
                'apt-get install -y --allow-unauthenticated --no-install-recommends '
                'ca-certificates curl wget sudo 2>&1'
            , timeout=300)

            verify = run_in_base(tmp,
                'command -v curl >/dev/null 2>&1 && command -v wget >/dev/null 2>&1 && echo BOTH_OK'
            , timeout=30)

            if "BOTH_OK" not in (verify.stdout or ""):
                log_warning(
                    "Base image: curl/wget install did NOT succeed. Sessions "
                    "will fail with 'Cannot install SSHX - no curl/wget "
                    "available'. apt-get output was:\n" + (core_result.stdout or "")[-2000:]
                )
            else:
                log_debug("curl and wget confirmed present in base image")

            # Now install the APT keyring so future `apt update` calls
            # inside user sessions verify signatures instead of failing
            # with NO_PUBKEY. This is separate from curl/wget so a failure
            # here (e.g. a slow mirror) can't also take down curl/wget.
            keyring_result = run_in_base(tmp,
                'export DEBIAN_FRONTEND=noninteractive; '
                'apt-get install -y --allow-unauthenticated --no-install-recommends '
                'ubuntu-keyring gnupg netbase dnsutils sudo 2>&1; '
                'apt-get update -qq 2>&1 || echo "WARNING: apt-get update still failing after keyring install"'
            , timeout=300)
            if keyring_result.stdout and ("NO_PUBKEY" in keyring_result.stdout or "is not signed" in keyring_result.stdout):
                log_warning(
                    "Base image: apt repos still unsigned after installing "
                    "ubuntu-keyring. Sessions may still see GPG errors on "
                    "`apt update`. Check network/mirror access during build."
                )
        else:
            log_debug("Skipping base image package installation (no isolation)")
    except Exception as e:
        log_warning(f"Base image setup warning: {e}")
    
    apply_hardening(tmp)
    
    shutil.rmtree(BASE, ignore_errors=True)
    os.replace(tmp, BASE)
    log("Ubuntu base image ready with network support")


def apply_hardening(root):
    """Install sudo in the base image. The namespace is the security boundary, not missing tools."""
    log("Installing sudo in base image (passwordless inside the workspace only)...")

    hardening_cmd = (
        'export DEBIAN_FRONTEND=noninteractive; '
        'apt-get install -y --allow-unauthenticated --no-install-recommends sudo 2>&1 || true; '
        'chmod 700 /root 2>/dev/null || true; '
        'chmod 600 /etc/shadow 2>/dev/null || true; '
        'true'
    )

    try:
        if have("proot") or os.geteuid() == 0:
            run_in_base(root, hardening_cmd, timeout=180)
        else:
            log_debug("Skipping base sudo install (no isolation helper)")
    except Exception as e:
        log_debug(f"Hardening warning: {e}")


# ============================================================================
# ISOLATION COMMAND BUILDERS
# ============================================================================

# Cache whether unshare supports the flags we need (checked once at startup)
_UNSHARE_PIDNS_OK = None


def _unshare_supports_pidns():
    """Check once whether `unshare --pid --mount-proc --fork` works on this host."""
    global _UNSHARE_PIDNS_OK
    if _UNSHARE_PIDNS_OK is not None:
        return _UNSHARE_PIDNS_OK
    if not have("unshare"):
        _UNSHARE_PIDNS_OK = False
        return False
    try:
        r = subprocess.run(
            ["unshare", "--pid", "--mount-proc", "--fork", "/bin/true"],
            capture_output=True, timeout=10
        )
        _UNSHARE_PIDNS_OK = (r.returncode == 0)
    except Exception:
        _UNSHARE_PIDNS_OK = False
    if not _UNSHARE_PIDNS_OK:
        log_warning(
            "unshare --pid/--mount-proc unavailable (needs CAP_SYS_ADMIN / "
            "not permitted here) — sessions will see the HOST /proc. "
            "Users will be able to see and signal host processes, "
            "including the DARKSSH server itself, unless you run the "
            "server inside its own container/VM."
        )
    return _UNSHARE_PIDNS_OK


def pcmd(root, cmd, session_ports=None):
    """
    Build command with appropriate isolation method.

    SECURITY FIX: previously /proc and /sys were bind-mounted straight from
    the host into every PRoot session. That let any session `kill -9` the
    DARKSSH server itself (e.g. `kill -9 $(lsof -t -i:4545)`) or any other
    session's process, because the host's real PID numbers and sockets were
    visible and signalable from inside the "sandbox".

    Fix: wrap PRoot in `unshare --pid --mount-proc --fork` so each session
    gets its OWN PID namespace. Inside the session, /proc only shows that
    session's own process tree (PID 1 = the session's own init/shell) — the
    host server process and other sessions' processes are not listed and
    cannot be sent signals, because they simply don't exist in that
    namespace. This is a real kernel-enforced boundary, unlike a bind mount.

    /sys is NOT bind-mounted anymore (it isn't needed for a dev shell and
    leaks host device/hardware info); PRoot provides an empty tmpfs-backed
    /sys inside the rootfs instead.
    """
    isolation = DETECTOR.can_isolate

    if isolation == "proot":
        inner = [
            "proot",
            "-r", str(root),
            "-0",  # Fake root (uid/gid mapping only — NOT a privilege boundary)
            "-b", "/dev:/dev",
            "-b", "/etc/resolv.conf:/etc/resolv.conf",
            "-b", "/etc/hosts:/etc/hosts",
            "-w", "/root",
            "/bin/sh", "-lc", cmd
        ]

        if _unshare_supports_pidns():
            # --fork is required with --pid so unshare itself becomes PID 1's
            # parent correctly; --mount-proc remounts /proc for the new
            # namespace so `ps`/`lsof -i`/`kill` inside the session only
            # ever see processes created inside that same session.
            return ["unshare", "--pid", "--mount-proc", "--fork"] + inner

        # No unshare available: fall back to old behavior but warn loudly.
        # We still avoid binding host /proc directly — proot fakes an
        # in-rootfs /proc by default, which is not perfect but is strictly
        # better than exposing real host PIDs.
        return inner

    elif isolation == "docker":
        docker_cmd = [
            "docker", "run", "--rm",
            "-v", f"{root}:/workspace:rw",
            "--network", "bridge",
            "--security-opt", "no-new-privileges",
            "--read-only",
            "--tmpfs", "/tmp",
            "--tmpfs", "/run",
            "-w", "/root",
            "ubuntu:24.04",
            "sh", "-c", cmd
        ]
        
        if session_ports:
            for port in session_ports[:3]:
                docker_cmd.extend(["-p", f"{port}:{port}"])
        
        return docker_cmd
    
    elif isolation == "chroot":
        return [
            "chroot", str(root),
            "/bin/sh", "-c", cmd
        ]
    
    else:
        log_debug("Running without isolation (reduced security)")
        return ["/bin/sh", "-c", cmd]


# ============================================================================
# WORKSPACE CLONING
# ============================================================================

def clone(dst, session_id=None, ports=None):
    """Clone base image to create new workspace"""
    tmp = dst.with_name(dst.name + ".new")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    
    a = subprocess.Popen(
        ["tar", "-C", str(BASE), "-cf", "-", "."],
        stdout=subprocess.PIPE
    )
    b = subprocess.Popen(
        ["tar", "-C", str(tmp), "-xf", "-"],
        stdin=a.stdout
    )
    a.stdout.close()
    
    if b.wait() != 0 or a.wait() != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("Workspace clone failed")
    
    os.replace(tmp, dst)
    apply_workspace_hardening(dst, session_id, ports)


def apply_workspace_hardening(dst, session_id=None, ports=None):
    """Privacy metadata for a workspace. Sudo and other tools stay installed."""
    stub_dir = dst / "usr/local/bin"
    if stub_dir.exists():
        for stub_name in ("sudo", "strace", "ltrace", "gdb", "tcpdump"):
            stub_path = stub_dir / stub_name
            try:
                if stub_path.is_file() and "is disabled" in stub_path.read_text(errors="replace"):
                    stub_path.unlink()
            except Exception:
                pass

    if session_id:
        session_info = {
            "session_id": session_id,
            "ports": ports or [],
            "network_enabled": ENABLE_OUTBOUND,
            "port_access_allowed": ALLOW_PORT_ACCESS,
            "created_at": time.time(),
        }
        try:
            (dst / ".darkssh_session.json").write_text(json.dumps(session_info, indent=2))
        except Exception:
            pass
    
    motd = (
        "=============================================\n"
        "       DARKSSH v3.1 - Secure Workspace\n"
        "=============================================\n"
    )
    if session_id:
        motd += f"  Session ID: {session_id}\n"
    if ports:
        motd += f"  Your Ports: {', '.join(map(str, ports[:3]))}\n"
    motd += (
        "  Network:   OUTBOUND ENABLED\n"
        "  Security:  ISOLATED\n"
        "=============================================\n"
        "\n"
    )
    
    try:
        (dst / "etc/motd").write_text(motd)
    except Exception:
        pass


# ============================================================================
# SESSION MANAGEMENT (FIXED: All errors handled)
# ============================================================================

def set_progress(sid, percent, stage, message=""):
    """Update session progress"""
    with LOCK:
        r = STATE["sessions"].get(sid)
        if r:
            r.update(
                progress=max(0, min(100, int(percent))),
                stage=stage,
                message=message,
                last_activity=time.time()
            )
            save()


def create_request(name):
    """Create a new session request with network isolation"""
    with LOCK:
        active = sum(
            r["status"] in ("queued", "starting", "running")
            for r in STATE["sessions"].values()
        )
        if active >= int(CFGDATA.get("max_sessions", 25)):
            raise RuntimeError("Maximum sessions reached")
        
        sid = secrets.token_hex(8)
        
        # Allocate private ports for this session
        ports = allocate_ports(sid)
        
        rec = {
            "id": sid,
            "name": (name or "workspace-" + sid[:6])[:80],
            "status": "queued",
            "progress": 1,
            "stage": "queued",
            "message": "Queued for a workspace worker",
            "sshx_url": None,
            "created_at": time.time(),
            "last_activity": time.time(),
            "ended_at": None,
            "error": None,
            "ports": ports,
            "network_enabled": ENABLE_OUTBOUND,
        }
        STATE["sessions"][sid] = rec
        READY_EVENTS[sid] = threading.Event()
        save()
    
    CREATE_POOL.submit(build_session, sid)
    return rec.copy()


def _mark_host_fallback():
    """Ubuntu base could not be downloaded. Sessions will overlay the host userspace."""
    if BASE.exists() and not (BASE / ".darkssh-fallback").exists():
        if not (BASE / "etc/os-release").exists():
            shutil.rmtree(BASE, ignore_errors=True)
    BASE.mkdir(parents=True, exist_ok=True)
    (BASE / ".darkssh-fallback").write_text("host-overlay\n")
    log_warning(
        "Ubuntu base image is not available. Using a private overlay of the "
        "host userspace so workspaces still start. Other users still cannot "
        "see each other's files. Delete data/ubuntu-base and restart to retry "
        "the Ubuntu download."
    )


def build_namespace_session(sid, session_ports):
    """Private root + private PIDs + 12 ports + passwordless sudo."""
    binary = isolate.ensure_binary(APP)
    set_progress(sid, 8, "preparing", "Preparing private workspace")
    try:
        ensure_base()
    except Exception as e:
        if not CFGDATA.get("allow_host_fallback", True):
            raise
        log_warning(f"Ubuntu base unavailable ({e})")
        _mark_host_fallback()
    fallback = (BASE / ".darkssh-fallback").exists()
    root = SESSIONS / sid / "rootfs"
    root.parent.mkdir(parents=True, exist_ok=True)
    if fallback:
        if root.exists():
            shutil.rmtree(root, ignore_errors=True)
        root.mkdir(parents=True, exist_ok=True)
        set_progress(sid, 20, "copying", "Creating private workspace")
    else:
        set_progress(sid, 20, "copying", "Creating isolated workspace from base")
        clone(root, sid, session_ports)
    set_progress(sid, 40, "network", "Allocating 12 private ports")
    rec = isolate.setup_net(sid, session_ports)
    if fallback:
        isolate.mount_fallback_usr(root, rec)
    isolate.write_privacy_files(root, sid, session_ports, fallback=fallback)
    isolate.write_launch_script(root, sid, session_ports)
    try:
        os.chmod(SESSIONS / sid, 0o700)
    except Exception:
        pass
    set_progress(sid, 65, "starting", "Starting private workspace")
    argv = isolate.launch_argv(binary, rec["ns"], root, session_ports)
    p = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        start_new_session=True,
    )
    with LOCK:
        PROCS[sid] = p
        if sid in STATE["sessions"]:
            STATE["sessions"][sid]["pid"] = p.pid
            STATE["sessions"][sid]["ports"] = list(session_ports or [])
            save()
    broker = isolate.find_broker_pid(p.pid, timeout=30)
    if broker:
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r:
                r["broker_pid"] = broker
                r["local_url"] = f"/term/{sid}"
                r.update(
                    status="running",
                    progress=100,
                    stage="ready",
                    message="Private workspace ready — sudo enabled, 12 ports",
                    last_activity=time.time(),
                )
                save()
        ev = READY_EVENTS.get(sid)
        if ev:
            ev.set()
    else:
        log_warning(f"Session {sid}: workspace broker did not come up")
    threading.Thread(target=watch, args=(sid, p), daemon=True).start()


def build_session(sid):
    """Build and start a session with full network isolation"""
    session_ports = None
    try:
        set_progress(sid, 5, "preparing", "Checking environment and dependencies")
        
        # Get allocated ports for this session
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r:
                session_ports = r.get("ports", [])
        
        isolation = DETECTOR.can_isolate
        
        if isolation == "namespace":
            build_namespace_session(sid, session_ports)
            return
        
        if isolation == "proot":
            if not ensure_proot():
                raise RuntimeError("PRoot unavailable and cannot be installed")
            
            ensure_base()
            set_progress(sid, 15, "base-ready", "Using shared cached base image")
            
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return
                r.update(status="starting", stage="workspace")
                save()
            
            root = SESSIONS / sid / "rootfs"
            root.parent.mkdir(parents=True, exist_ok=True)
            
            set_progress(sid, 25, "copying", "Creating isolated workspace from base")
            clone(root, sid, session_ports)
            set_progress(sid, 50, "bootstrap", "Workspace ready with network access")
            
            set_progress(sid, 65, "starting", "Launching SSHX process (v3.1)")
            
            port_info = ",".join(map(str, session_ports[:3])) if session_ports else "default"
            cmd = f"""set -e
export HOME=/root
export USER=root
export LOGNAME=root
export HOSTNAME="dark-workspace"
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export TERM=dumb
export TERMINFO=/usr/share/terminfo
export NETWORK_ENABLED=1
export DARKSSH_SESSION="{sid}"
export DARKSSH_PORTS="{port_info}"
export PS1="dark@workspace:\\w$ "

if [ -f /etc/motd ]; then
    cat /etc/motd
fi

echo ""
echo "Network: OUTBOUND INTERNET ENABLED"
echo "Ports are private and isolated"
echo ""

if [ -x /tmp/sshx ]; then
    exec /tmp/sshx --quiet
elif command -v sshx >/dev/null 2>&1; then
    exec sshx --quiet
elif [ -x /usr/local/bin/sshx ]; then
    exec /usr/local/bin/sshx --quiet
elif command -v curl >/dev/null 2>&1; then
    echo "Installing SSHX via curl..."
    curl -sSfL https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/
    chmod +x /tmp/sshx
    exec /tmp/sshx --quiet
elif command -v wget >/dev/null 2>&1; then
    echo "Installing SSHX via wget..."
    wget -qO- https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/
    chmod +x /tmp/sshx
    exec /tmp/sshx --quiet
else
    echo "ERROR: Cannot install SSHX - no curl/wget available"
    exit 1
fi"""
            
            p = subprocess.Popen(
                pcmd(root, cmd, session_ports),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
            )
            
        elif isolation == "docker":
            raise RuntimeError("Docker mode not yet fully implemented - use PRoot or direct mode")
            
        else:
            log(f"Session {sid}: Using direct mode (no filesystem isolation)")

            # SECURITY: In direct mode there is no rootfs/chroot at all, so a
            # session's shell is otherwise a completely ordinary process on
            # this host, in the host's real PID namespace. That's exactly
            # what allowed `kill -9 $(lsof -t -i:4545)` to hit the DARKSSH
            # server itself. If `unshare --pid --mount-proc --fork` works
            # here, use it: the session then gets its OWN /proc, so `ps`,
            # `lsof -i`, and `kill` inside the session can only see/signal
            # processes started inside that same session — the host server
            # and other sessions are invisible and unreachable. If unshare
            # isn't available (no CAP_SYS_ADMIN — common in unprivileged
            # containers), warn loudly instead of silently pretending this
            # is "isolation".
            direct_has_pidns = _unshare_supports_pidns()
            if not direct_has_pidns:
                log_warning(
                    f"Session {sid}: running in DIRECT mode with NO process "
                    f"isolation available. This session can see and signal "
                    f"host processes, including this DARKSSH server. Install "
                    f"proot, or run this server itself inside a container "
                    f"with CAP_SYS_ADMIN so unshare works, to fix this."
                )

            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return
                r.update(status="starting", stage="workspace")
                save()
            
            root = SESSIONS / sid / "workspace"
            root.mkdir(parents=True, exist_ok=True)
            
            set_progress(sid, 25, "preparing", "Preparing direct workspace")
            set_progress(sid, 50, "ready", "Workspace ready (direct mode)")
            set_progress(sid, 65, "starting", "Launching SSHX process")
            
            port_info = ",".join(map(str, session_ports[:3])) if session_ports else "default"
            cmd = f"""set -e
export HOME="{os.path.expanduser('~')}"
export USER="{os.environ.get('USER', 'user')}"
export LOGNAME="{os.environ.get('USER', 'user')}"
export HOSTNAME="dark-workspace"
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
export TERM="${{TERM:-dumb}}"
export WORKSPACE="{root}"
export DARKSSH_SESSION="{sid}"
export DARKSSH_PORTS="{port_info}"
export NETWORK_ENABLED=1
export PS1="dark@workspace:\\w$ "

mkdir -p "$WORKSPACE" 2>/dev/null || true
cd "$WORKSPACE" || cd /tmp

echo "============================================="
echo " DARKSSH v3.1 Direct Workspace"
echo " Session: {sid}"
echo " Network: OUTBOUND ENABLED"
echo " Started: $(date)"
echo "============================================="
echo ""

if [ -x /tmp/sshx ]; then
    exec /tmp/sshx --quiet
elif command -v sshx >/dev/null 2>&1; then
    exec sshx --quiet
elif command -v curl >/dev/null 2>&1; then
    curl -sSfL https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/
    chmod +x /tmp/sshx
    exec /tmp/sshx --quiet
elif command -v wget >/dev/null 2>&1; then
    wget -qO- https://s3.amazonaws.com/sshx/sshx-x86_64-unknown-linux-musl.tar.gz | tar xz -C /tmp/
    chmod +x /tmp/sshx
    exec /tmp/sshx --quiet
else
    echo "ERROR: Cannot install SSHX"
    exit 1
fi"""

            base_argv = ["/bin/sh", "-c", cmd]
            if direct_has_pidns:
                argv = ["unshare", "--pid", "--mount-proc", "--fork"] + base_argv
            else:
                argv = base_argv

            p = subprocess.Popen(
                argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
                cwd=str(root)
            )
        
        with LOCK:
            PROCS[sid] = p
            STATE["sessions"][sid]["pid"] = p.pid
            save()
        
        set_progress(sid, 75, "sshx", "SSHX running, waiting for access URL")
        
        threading.Thread(target=watch, args=(sid, p), daemon=True).start()
        
    except Exception as e:
        log(f"Session {sid} FAILED: {e}")
        try:
            isolate.teardown(sid)
        except Exception:
            pass
        # Release ports on failure
        if session_ports:
            release_ports(session_ports)
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r:
                r.update(
                    status="error",
                    progress=100,
                    stage="error",
                    message="Creation failed",
                    error=str(e),
                    ended_at=time.time()
                )
                save()
        PROCS.pop(sid, None)


def watch(sid, p):
    """Watch SSHX process output for URL (FIXED: Proper error handling)"""
    rc = 1
    # FIX: keep the tail of the launch script's own output so that if the
    # process dies (e.g. "SSHX exited with code 127"), the API response and
    # session record can show WHY, instead of just the bare exit code. This
    # was previously only visible in the server's own terminal/log, making
    # every failure a guessing game for anyone hitting the API remotely.
    tail_lines = deque(maxlen=25)
    try:
        for line in p.stdout:
            if line is None:
                break
            line = line.strip()
            if line:
                tail_lines.append(line)
                # Filter PRoot warnings
                if "proot warning" in line.lower() or "ptrace" in line.lower():
                    log_debug(f"{sid}: [PROOT] {line}")
                elif "tput error" in line.lower():
                    log_debug(f"{sid}: [TERM] {line}")
                else:
                    log(f"{sid}: {line}")
            
            if "DARKSSH_LOCAL_READY" in line:
                with LOCK:
                    r = STATE["sessions"].get(sid)
                    if r and not r.get("local_url"):
                        r["local_url"] = f"/term/{sid}"
                        r.update(
                            status="running",
                            progress=100,
                            stage="ready",
                            message="Private workspace ready — sudo enabled, 12 ports",
                            last_activity=time.time(),
                        )
                        save()
                ev = READY_EVENTS.get(sid)
                if ev:
                    ev.set()

            m = URLRE.search(line)
            if m:
                with LOCK:
                    r = STATE["sessions"].get(sid)
                    url = m.group(0).rstrip(".,);]")
                    if r:
                        r.update(
                            status="running",
                            progress=100,
                            stage="ready",
                            message="SSHX session ready - Network enabled",
                            sshx_url=url,
                            last_activity=time.time()
                        )
                        save()
                
                ev = READY_EVENTS.get(sid)
                if ev:
                    ev.set()
        
        rc = p.wait()
        
    except Exception as e:
        log(f"{sid} watch error: {e}")
    finally:
        try:
            isolate.teardown(sid)
        except Exception:
            pass
        # Release ports when session ends
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r and "ports" in r and r["ports"]:
                release_ports(r["ports"])
                log_debug(f"Released ports for session {sid}")
            
            if r and r["status"] != "deleted":
                r["status"] = "stopped" if rc == 0 else "error"
                r["ended_at"] = time.time()
                if rc and not r.get("error"):
                    r["error"] = f"SSHX exited with code {rc}"
                if rc:
                    r["error_output"] = list(tail_lines)
                save()
            
            ev = READY_EVENTS.get(sid)
            if ev:
                ev.set()
            PROCS.pop(sid, None)


def delete(sid):
    """Delete a session and release its resources"""
    with LOCK:
        r = STATE["sessions"].get(sid)
        if not r:
            return False
        
        # Release ports
        if "ports" in r and r["ports"]:
            release_ports(r["ports"])
            log(f"Released ports for session {sid}")
        
        p = PROCS.get(sid)
        if p and p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGTERM)
                p.wait(5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        try:
            isolate.teardown(sid)
        except Exception:
            pass
        
        shutil.rmtree(SESSIONS / sid, ignore_errors=True)
        r["status"] = "deleted"
        r["ended_at"] = time.time()
        save()
        
        ev = READY_EVENTS.get(sid)
        if ev:
            ev.set()
        PROCS.pop(sid, None)
        return True


def public(r):
    """Return safe public data for a session"""
    return {
        k: r.get(k) 
        for k in (
            "id", "name", "status", "progress", "stage", 
            "message", "sshx_url", "local_url", "ports", "created_at", 
            "last_activity", "ended_at", "error",
            "network_enabled", "error_output",
        )
    }


# ============================================================================
# JANITOR (Cleanup idle sessions)
# ============================================================================

def janitor():
    """Background thread to clean up idle sessions"""
    while True:
        time.sleep(15)
        now = time.time()
        limit = max(60, int(CFGDATA["idle_minutes"]) * 60)
        
        with LOCK:
            alive = []
            for sid, r in STATE["sessions"].items():
                proc = PROCS.get(sid)
                if proc is not None and proc.poll() is None:
                    r["last_activity"] = now
                    alive.append(sid)
            if alive:
                save()
            ids = [
                sid for sid, r in STATE["sessions"].items()
                if r["status"] in ("queued", "starting", "running")
                and sid not in alive
                and now - r.get("last_activity", now) >= limit
            ]
        
        for sid in ids:
            log(f"Idle timeout: {sid}")
            delete(sid)


threading.Thread(target=janitor, daemon=True).start()


# ============================================================================
# HTTP API SERVER
# ============================================================================

def _term_page(sid, rec):
    ports = ", ".join(str(p) for p in (rec.get("ports") or []))
    name = str(rec.get("name") or sid)
    name = name.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DARKSSH {sid}</title>
<style>
body{{margin:0;background:#07070b;color:#f5f5f7;font:14px ui-monospace,monospace}}
header{{padding:14px 18px;background:#12131c;border-bottom:1px solid #292b3b}}
b{{letter-spacing:2px}}
#out{{white-space:pre-wrap;padding:16px;min-height:55vh}}
form{{display:flex;gap:8px;padding:12px;border-top:1px solid #292b3b;position:sticky;bottom:0;background:#0c0d14}}
input,button{{font:inherit;border-radius:10px;border:1px solid #303244;background:#090a10;color:white;padding:10px}}
input{{flex:1}}
button{{background:#9145dc;font-weight:700;cursor:pointer}}
.muted{{color:#999daf}}
</style></head><body>
<header><b>DARKSSH</b> <span class="muted">{name} · session {sid}<br>Your 12 ports: {ports}<br>sudo is enabled. You can only stop processes and ports you started.</span></header>
<div id="out">Connecting to private workspace…\n</div>
<form onsubmit="return go()">
<input id="cmd" autofocus placeholder="command, for example: sudo apt-get update">
<button>Run</button>
<button type="button" onclick="preset('sudo apt-get update')">apt update</button>
</form>
<script>
const sid={sid!r};
const out=document.getElementById('out');
const cmd=document.getElementById('cmd');
function preset(v){{cmd.value=v; go();}}
async function go(){{
  const c=cmd.value;
  if(!c.trim()) return false;
  out.textContent += '$ '+c+'\\n';
  cmd.value='';
  try{{
    const r=await fetch('/term/'+sid+'/exec',{{method:'POST',headers:{{'Content-Type':'text/plain'}},body:c}});
    const d=await r.json();
    out.textContent += (d.output||d.error||'')+'\\n';
  }}catch(e){{ out.textContent += String(e)+'\\n'; }}
  out.scrollTop=out.scrollHeight;
  return false;
}}
out.textContent = 'Private workspace ready.\\nType a command, or press apt update.\\n';
</script></body></html>"""


class H(BaseHTTPRequestHandler):
    """HTTP request handler with API authentication"""
    
    def log_message(self, *a):
        pass
    
    def send_cors_headers(self):
        """Send CORS headers"""
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
    
    def do_OPTIONS(self):
        """Handle preflight requests"""
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()
    
    def send_json(self, code, obj):
        """
        Send JSON response.

        FIX: if the client has already disconnected (closed the tab, lost
        the connection, etc.) before we respond, writing to self.wfile
        raises BrokenPipeError/ConnectionResetError. That's an ordinary,
        expected occurrence for any HTTP server — not a bug — so we log it
        quietly and return instead of letting it propagate. Previously this
        exception escaped send_json, got caught by a `except Exception`
        handler elsewhere that itself called send_json again on the same
        dead socket, raising a SECOND unhandled exception and printing an
        ugly double traceback to the server log.
        """
        try:
            data = json.dumps(obj).encode()
            self.send_response(code)
            self.send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            log_debug("Client disconnected before response could be sent")
        except Exception as e:
            log_debug(f"send_json failed: {e}")
    
    def read_body(self):
        """Read request body"""
        length = int(self.headers.get("Content-Length", "0"))
        if length > 65536:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(length) or b"{}")
    
    def do_GET(self):
        """Handle GET requests"""
        path = urlparse(self.path).path
        
        if path in ("/", "/index.html"):
            try:
                html = (APP / "static/index.html").read_bytes()
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(html)))
                self.end_headers()
                self.wfile.write(html)
            except Exception as e:
                self.send_json(500, {"error": str(e)})
            return
        
        if path.startswith("/term/"):
            sid = path.strip("/").split("/")[-1]
            if not re.fullmatch(r"[0-9a-f]{16}", sid):
                return self.send_json(400, {"error": "Bad session id"})
            with LOCK:
                r = STATE["sessions"].get(sid)
            if not r:
                return self.send_json(404, {"error": "Session not found"})
            html = _term_page(sid, r).encode()
            try:
                self.send_response(200)
                self.send_cors_headers()
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(html)))
                self.end_headers()
                self.wfile.write(html)
            except (BrokenPipeError, ConnectionResetError):
                pass
            return

        if path == "/api/health":
            return self.send_json(200, {
                "ok": True,
                "port": CFGDATA["port"],
                "version": "3.2.0",
                "universal": UNIVERSAL_MODE,
                "system": DETECTOR.get_info_dict(),
                "auth": "enabled" if API_KEY else "disabled",
                "network": {
                    "outbound_enabled": ENABLE_OUTBOUND,
                    "port_isolation": True,
                    "base_port": BASE_PORT,
                    "ports_per_session": PORTS_PER_SESSION,
                },
                "active_sessions": sum(
                    1 for r in STATE["sessions"].values()
                    if r["status"] in ("queued", "starting", "running")
                ),
            })
        
        if not check_auth(self.headers):
            return self.send_json(401, {"error": "Unauthorized — API key required"})
        
        if path == "/api/sessions":
            with LOCK:
                sessions = [public(r) for r in STATE["sessions"].values()]
            return self.send_json(200, {"sessions": sessions})
        
        if path.startswith("/api/sessions/"):
            sid = path.rsplit("/", 1)[-1]
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return self.send_json(404, {"error": "Session not found"})
                return self.send_json(200, public(r))
        
        self.send_error(404)
    
    def do_POST(self):
        """Handle POST requests"""
        path = urlparse(self.path).path
        
        if path.startswith("/term/") and path.endswith("/exec"):
            parts = [p for p in path.split("/") if p]
            # term/<sid>/exec
            if len(parts) != 3 or not re.fullmatch(r"[0-9a-f]{16}", parts[1]):
                return self.send_json(400, {"error": "Bad session id"})
            sid = parts[1]
            with LOCK:
                r = STATE["sessions"].get(sid)
                broker = r.get("broker_pid") if r else None
                pid = r.get("pid") if r else None
            if not r or r.get("status") not in ("running", "starting"):
                return self.send_json(404, {"error": "Session is not running"})
            length = int(self.headers.get("Content-Length", "0") or 0)
            if length > 65536:
                return self.send_json(400, {"error": "Command too long"})
            cmd = self.rfile.read(length).decode("utf-8", "replace")
            target = broker or pid
            if not target:
                return self.send_json(409, {"error": "Workspace is still starting"})
            try:
                code, out = isolate.broker_exec(int(target), cmd, timeout=180)
            except Exception as e:
                return self.send_json(500, {"error": str(e)})
            with LOCK:
                rr = STATE["sessions"].get(sid)
                if rr:
                    rr["last_activity"] = time.time()
                    save()
            return self.send_json(200, {"ok": code == 0, "code": code, "output": out})

        if not check_auth(self.headers):
            return self.send_json(401, {"error": "Unauthorized — API key required"})
        
        if path == "/api/sessions":
            try:
                data = self.read_body()
            except Exception as e:
                return self.send_json(400, {"error": str(e)})
            
            try:
                rec = create_request(str(data.get("name", "")))
                
                query = urlparse(self.path).query.lower()
                wait = query not in ("wait=false", "async=1")
                
                if not wait:
                    return self.send_json(202, {
                        "ok": True,
                        "ready": False,
                        "session": public(rec)
                    })
                
                ev = READY_EVENTS[rec["id"]]
                if not ev.wait(240):
                    return self.send_json(504, {
                        "ok": False,
                        "ready": False,
                        "error": "Timed out waiting for SSHX URL",
                        "session": public(STATE["sessions"].get(rec["id"], rec))
                    })
                
                with LOCK:
                    final = STATE["sessions"].get(rec["id"])
                
                if not final:
                    return self.send_json(404, {
                        "ok": False,
                        "error": "Session disappeared"
                    })
                
                if final.get("sshx_url") or final.get("local_url"):
                    return self.send_json(200, {
                        "ok": True,
                        "ready": True,
                        "session": public(final)
                    })
                
                return self.send_json(502, {
                    "ok": False,
                    "ready": False,
                    "error": final.get("error") or "SSHX exited before producing URL",
                    "session": public(final)
                })
                
            except Exception as e:
                log(f"Create session error: {e}")
                return self.send_json(500, {"error": str(e)})
        
        if path.startswith("/api/sessions/") and path.endswith("/heartbeat"):
            sid = path.split("/")[-2]
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r:
                    return self.send_json(404, {"error": "Session not found"})
                r["last_activity"] = time.time()
                save()
            return self.send_json(200, {"ok": True})
        
        self.send_error(404)
    
    def do_DELETE(self):
        """Handle DELETE requests"""
        path = urlparse(self.path).path
        
        if not check_auth(self.headers):
            return self.send_json(401, {"error": "Unauthorized — API key required"})
        
        if path.startswith("/api/sessions/"):
            sid = path.rsplit("/", 1)[-1]
            ok = delete(sid)
            return self.send_json(200 if ok else 404, {"ok": ok})
        
        self.send_error(404)


def check_auth(headers):
    """Check API key authentication"""
    if not API_KEY:
        return True
    
    auth = headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:]
        return secrets.compare_digest(token, API_KEY)
    return False


# ============================================================================
# CLEANUP ON EXIT
# ============================================================================

def cleanup():
    """Clean up all sessions on exit"""
    log("Shutting down - cleaning up sessions...")
    with LOCK:
        for sid in list(PROCS.keys()):
            try:
                delete(sid)
            except Exception:
                pass
    try:
        isolate.teardown_all()
    except Exception:
        pass


atexit.register(cleanup)


def _on_signal(signum, frame):
    log(f"Signal {signum} — cleaning up workspaces")
    try:
        cleanup()
    finally:
        os._exit(0)


signal.signal(signal.SIGTERM, _on_signal)
signal.signal(signal.SIGINT, _on_signal)


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    banner = """
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║     ██████╗ ██╗   ██╗ █████╗ ███╗   ██╗ ██████╗ ███████╗        ║
║     ██╔══██╗██║   ██║██╔══██╗████╗  ██║██╔════╝ ██╔════╝        ║
║     ██████╔╝██║   ██║███████║██╔██╗ ██║██║  ███╗█████╗          ║
║     ██╔══██╗██║   ██║██╔══██║██║╚██╗██║██║   ██║██╔══╝          ║
║     ██████╔╝╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝███████╗        ║
║     ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝        ║
║                                                                   ║
║                    ★ v3.1 - FULLY FIXED ★                        ║
║         Network Isolation • Port Security • Full Internet        ║
╚═══════════════════════════════════════════════════════════════════╝
"""
    print(banner)
    
    if API_KEY:
        log("API key authentication ENABLED")
    else:
        log("WARNING: API key authentication DISABLED")
    
    sys_info = DETECTOR.get_info_dict()
    log(f"System: {sys_info['os_name']} ({sys_info['architecture']})")
    log(f"Isolation: {sys_info['isolation_method']}")
    log(f"Universal Mode: {'Yes' if UNIVERSAL_MODE else 'No'}")
    log(f"Network: {'OUTBOUND ENABLED' if ENABLE_OUTBOUND else 'DISABLED'}")
    log(f"Port Isolation: Yes (base port: {BASE_PORT})")
    
    supported, message = DETECTOR.is_supported()
    if not supported:
        log(f"FATAL: {message}")
        sys.exit(1)
    elif "warning" in message.lower() or "reduced" in message.lower():
        log(f"WARNING: {message}")
    
    # Processes do not survive a restart. Drop stale "running" records so they
    # do not consume the session limit or look alive with no workspace behind them.
    with LOCK:
        changed = False
        for r in STATE["sessions"].values():
            if r.get("status") in ("queued", "starting", "running"):
                r.update(status="stopped", stage="stopped", ended_at=time.time(),
                         message="Server restarted")
                changed = True
        if changed:
            save()

    log(f"Listening on {CFGDATA['host']}:{CFGDATA['port']}")
    log("")
    log("★ DARKSSH v3.1 Fully Fixed - Ready! ★")
    log("")
    
    try:
        server = ThreadingHTTPServer(
            (CFGDATA["host"], int(CFGDATA["port"])),
            H
        )
        server.serve_forever()
    except KeyboardInterrupt:
        log("Server shutting down...")
        cleanup()
        sys.exit(0)
    except Exception as e:
        log(f"Server error: {e}")
        sys.exit(1)
